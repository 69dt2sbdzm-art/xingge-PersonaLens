import { useState, useEffect } from 'react';
import { View, Text, Picker, ScrollView } from '@tarojs/components';
import Taro, { useLoad } from '@tarojs/taro';
import { getAllTypeCodes, getTypeByCode, getTypeEmoji } from '@/data/mbti-types';
import { calculateMatch } from '@/lib/mbti-match';
import DimensionAnalysis from '@/components/dimension-analysis';

const typeOptions = getAllTypeCodes().map((code) => {
  const type = getTypeByCode(code);
  return { label: `${getTypeEmoji(code)} ${code} - ${type?.name}`, value: code };
});

// 根据匹配度获取颜色配置
function getScoreColorConfig(score: number) {
  if (score < 60) {
    return {
      text: '#fbbf24',
      bar: 'linear-gradient(90deg, #fbbf24, #f59e0b)',
      levelText: '需要磨合',
      levelColor: '#fbbf24',
      effect: null as null,
    };
  } else if (score < 80) {
    return {
      text: '#fdba74', // 淡橙色
      bar: 'linear-gradient(90deg, #fdba74, #fb923c)',
      levelText: '良好匹配',
      levelColor: '#fdba74',
      effect: 'flower' as const,
    };
  } else {
    return {
      text: '#f472b6',
      bar: 'linear-gradient(90deg, #f472b6, #ec4899)',
      levelText: '绝佳搭档',
      levelColor: '#f472b6',
      effect: 'heart' as const,
    };
  }
}

// 生成随机粒子
function generateParticles(type: 'flower' | 'heart', count: number) {
  const particles = [];
  for (let i = 0; i < count; i++) {
    particles.push({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 2,
      duration: 2 + Math.random() * 2,
      size: 12 + Math.random() * 16,
      emoji: type === 'flower' ? '🌸' : '❤️',
    });
  }
  return particles;
}

export default function MatchPage() {
  const [type1, setType1] = useState('INTJ');
  const [type2, setType2] = useState('ENFP');
  const [matchResult, setMatchResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'work' | 'romantic'>('work');
  const [showEffect, setShowEffect] = useState(false);
  const [effectType, setEffectType] = useState<'flower' | 'heart' | null>(null);
  const [particles, setParticles] = useState<any[]>([]);

  const calculateAndSetMatch = (t1: string, t2: string) => {
    try {
      const result = calculateMatch(t1, t2);
      setMatchResult(result);
      
      const config = getScoreColorConfig(result.overallScore);
      if (config.effect) {
        setEffectType(config.effect);
        setShowEffect(true);
        setParticles(generateParticles(config.effect, config.effect === 'flower' ? 20 : 15));
        
        // 3秒后隐藏特效
        setTimeout(() => setShowEffect(false), 3000);
      } else {
        setShowEffect(false);
      }
    } catch (e) {
      console.error('匹配度计算失败:', e);
    }
  };

  useLoad(() => {
    console.log('匹配页面加载完成');
    calculateAndSetMatch('INTJ', 'ENFP');
  });

  useEffect(() => {
    if (type1 && type2) {
      calculateAndSetMatch(type1, type2);
    }
  }, [type1, type2]);

  const handleType1Change = (e: any) => {
    const index = Number(e.detail.value);
    setType1(typeOptions[index].value);
  };

  const handleType2Change = (e: any) => {
    const index = Number(e.detail.value);
    setType2(typeOptions[index].value);
  };

  const type1Info = getTypeByCode(type1);
  const type2Info = getTypeByCode(type2);
  const colorConfig = matchResult ? getScoreColorConfig(matchResult.overallScore) : null;

  return (
    <View className="min-h-screen relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)' }}>
      {/* CSS动画特效层 */}
      {showEffect && particles.map((p) => (
        <View
          key={p.id}
          className="fixed pointer-events-none"
          style={{
            left: `${p.left}%`,
            bottom: '-20px',
            fontSize: `${p.size}px`,
            animation: `floatUp ${p.duration}s ease-out ${p.delay}s forwards`,
            opacity: 0,
            zIndex: 100,
          }}
        >
          <Text>{p.emoji}</Text>
        </View>
      ))}

      {/* 注入CSS动画关键帧 */}
      <View className="hidden">
        <style>{`
          @keyframes floatUp {
            0% {
              transform: translateY(0) scale(0.3) rotate(0deg);
              opacity: 0;
            }
            20% {
              opacity: 1;
              transform: translateY(-50px) scale(0.8) rotate(20deg);
            }
            100% {
              transform: translateY(-400px) scale(1.2) rotate(360deg);
              opacity: 0;
            }
          }
        `}</style>
      </View>

      <ScrollView className="h-full" scrollY>
        {/* 标题区 */}
        <View className="px-5 pt-8 pb-4 text-center">
          <Text className="text-white text-2xl font-bold block mb-1">MBTI关系匹配</Text>
          <Text className="text-sm" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>深度分析两种类型的互动模式和兼容性</Text>
        </View>

        {/* 类型选择器 - 美化版 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <View className="flex items-center gap-3">
              {/* 类型1 */}
              <View className="flex-1">
                <Text className="text-xs mb-2 block text-center" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>你的类型</Text>
                <Picker mode="selector" range={typeOptions.map((o) => o.label)} onChange={handleType1Change}>
                  <View
                    className="w-full border rounded-xl p-3 flex flex-col items-center gap-1"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      borderColor: 'rgba(255, 255, 255, 0.25)',
                    }}
                  >
                    <View
                      className="w-12 h-12 rounded-full flex items-center justify-center mb-1"
                      style={{
                        background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.4), rgba(118, 75, 162, 0.4))',
                        boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)',
                      }}
                    >
                      <Text className="text-2xl">{getTypeEmoji(type1)}</Text>
                    </View>
                    <Text className="text-white text-sm font-bold">{type1}</Text>
                    <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{type1Info?.name}</Text>
                  </View>
                </Picker>
              </View>

              {/* 爱心连接图标 */}
              <View className="flex-shrink-0 mt-8">
                <View
                  className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, #f093fb, #f5576c)',
                    boxShadow: '0 4px 12px rgba(240, 147, 251, 0.4)',
                  }}
                >
                  <Text className="text-lg">💕</Text>
                </View>
              </View>

              {/* 类型2 */}
              <View className="flex-1">
                <Text className="text-xs mb-2 block text-center" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>对方类型</Text>
                <Picker mode="selector" range={typeOptions.map((o) => o.label)} onChange={handleType2Change}>
                  <View
                    className="w-full border rounded-xl p-3 flex flex-col items-center gap-1"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.1)',
                      borderColor: 'rgba(255, 255, 255, 0.25)',
                    }}
                  >
                    <View
                      className="w-12 h-12 rounded-full flex items-center justify-center mb-1"
                      style={{
                        background: 'linear-gradient(135deg, rgba(240, 147, 251, 0.4), rgba(245, 87, 108, 0.4))',
                        boxShadow: '0 4px 12px rgba(240, 147, 251, 0.3)',
                      }}
                    >
                      <Text className="text-2xl">{getTypeEmoji(type2)}</Text>
                    </View>
                    <Text className="text-white text-sm font-bold">{type2}</Text>
                    <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{type2Info?.name}</Text>
                  </View>
                </Picker>
              </View>
            </View>
          </View>
        </View>

        {/* 匹配度展示 */}
        {matchResult && colorConfig && (
          <View className="px-5 mb-4">
            <View
              className="backdrop-blur-md border rounded-2xl p-5 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              {/* 类型图标 + 百分比 */}
              <View className="flex items-center justify-center gap-4 mb-3">
                <View className="text-center">
                  <View
                    className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-1"
                    style={{
                      background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.3), rgba(118, 75, 162, 0.3))',
                      boxShadow: '0 4px 12px rgba(102, 126, 234, 0.2)',
                    }}
                  >
                    <Text className="text-2xl">{getTypeEmoji(type1)}</Text>
                  </View>
                  <Text className="text-white text-sm font-bold">{type1}</Text>
                </View>
                
                <View className="text-center">
                  <Text className="text-5xl font-bold block" style={{ color: colorConfig.text }}>
                    {matchResult.overallScore}%
                  </Text>
                </View>
                
                <View className="text-center">
                  <View
                    className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-1"
                    style={{
                      background: 'linear-gradient(135deg, rgba(240, 147, 251, 0.3), rgba(245, 87, 108, 0.3))',
                      boxShadow: '0 4px 12px rgba(240, 147, 251, 0.2)',
                    }}
                  >
                    <Text className="text-2xl">{getTypeEmoji(type2)}</Text>
                  </View>
                  <Text className="text-white text-sm font-bold">{type2}</Text>
                </View>
              </View>

              {/* 等级文字 */}
              <View className="text-center mb-3">
                <Text className="text-base font-bold block" style={{ color: colorConfig.levelColor }}>
                  {colorConfig.levelText}
                </Text>
              </View>

              {/* 进度条 - 带发光效果 */}
              <View className="w-full h-4 rounded-full overflow-visible relative" style={{ backgroundColor: 'rgba(255, 255, 255, 0.15)' }}>
                {/* 发光背景层 */}
                <View
                  className="absolute inset-0 rounded-full"
                  style={{
                    width: `${matchResult.overallScore}%`,
                    background: colorConfig.bar,
                    filter: 'blur(8px)',
                    opacity: 0.6,
                  }}
                />
                {/* 主进度条 */}
                <View
                  className="relative h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${matchResult.overallScore}%`,
                    background: colorConfig.bar,
                    boxShadow: `0 0 10px ${colorConfig.text}60, 0 0 20px ${colorConfig.text}30`,
                  }}
                />
              </View>
            </View>
          </View>
        )}

        {/* 四维度深度解析 */}
        {matchResult && (
          <View className="px-5 mb-4">
            <View
              className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              <View className="flex items-center gap-2 mb-4">
                <Text className="text-lg">📊</Text>
                <Text className="text-white text-base font-bold">四维度深度解析</Text>
              </View>
              <DimensionAnalysis dimensions={matchResult.dimensions} />
            </View>
          </View>
        )}

        {/* Tab切换：工作兼容性 / 感情火花值 */}
        {matchResult && (
          <View className="px-5 mb-4">
            <View
              className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              {/* Tab头部 */}
              <View className="flex mb-4" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.2)' }}>
                <View
                  className="flex-1 pb-2 text-center cursor-pointer"
                  onClick={() => setActiveTab('work')}
                  style={{ borderBottom: activeTab === 'work' ? '2px solid #667eea' : '2px solid transparent' }}
                >
                  <Text className={`text-sm font-medium ${activeTab === 'work' ? 'text-white' : ''}`} style={activeTab !== 'work' ? { color: 'rgba(255, 255, 255, 0.6)' } : {}}>
                    💼 工作与事业
                  </Text>
                </View>
                <View
                  className="flex-1 pb-2 text-center cursor-pointer"
                  onClick={() => setActiveTab('romantic')}
                  style={{ borderBottom: activeTab === 'romantic' ? '2px solid #f093fb' : '2px solid transparent' }}
                >
                  <Text className={`text-sm font-medium ${activeTab === 'romantic' ? 'text-white' : ''}`} style={activeTab !== 'romantic' ? { color: 'rgba(255, 255, 255, 0.6)' } : {}}>
                    💝 感情火花
                  </Text>
                </View>
              </View>

              {/* 工作兼容性内容 */}
              {activeTab === 'work' && matchResult.workCompatibility && (
                <View>
                  <View className="mb-4">
                    <View className="flex items-center justify-between mb-2">
                      <Text className="text-white text-sm font-semibold">兼容性评分</Text>
                      <Text className="text-white text-lg font-bold">{matchResult.workCompatibility.score}%</Text>
                    </View>
                    <View className="w-full h-2 rounded-full" style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}>
                      <View
                        className="h-full rounded-full"
                        style={{
                          width: `${matchResult.workCompatibility.score}%`,
                          background: 'linear-gradient(90deg, #667eea, #764ba2)',
                        }}
                      />
                    </View>
                  </View>

                  <View className="mb-4">
                    <Text className="text-white text-sm font-semibold mb-2 block">✅ 协作优势</Text>
                    <View className="space-y-2">
                      {matchResult.workCompatibility.collaborationStrengths.map((item: string, idx: number) => (
                        <View key={idx} className="flex items-start gap-2">
                          <View className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#10b981' }} />
                          <Text className="text-xs flex-1 leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  <View className="mb-4">
                    <Text className="text-white text-sm font-semibold mb-2 block">⚠️ 潜在摩擦</Text>
                    <View className="space-y-2">
                      {matchResult.workCompatibility.potentialFrictions.map((item: string, idx: number) => (
                        <View key={idx} className="flex items-start gap-2">
                          <View className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#f59e0b' }} />
                          <Text className="text-xs flex-1 leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  <View>
                    <Text className="text-white text-sm font-semibold mb-2 block">💡 实践建议</Text>
                    <View className="space-y-2">
                      {matchResult.workCompatibility.practicalAdvice.map((item: string, idx: number) => (
                        <View key={idx} className="flex items-start gap-2">
                          <View className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#3b82f6' }} />
                          <Text className="text-xs flex-1 leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>
              )}

              {/* 感情火花值内容 */}
              {activeTab === 'romantic' && matchResult.romanticSpark && (
                <View>
                  <View className="mb-4">
                    <View className="flex items-center justify-between mb-2">
                      <Text className="text-white text-sm font-semibold">火花值评分</Text>
                      <Text className="text-white text-lg font-bold">{matchResult.romanticSpark.score}%</Text>
                    </View>
                    <View className="w-full h-2 rounded-full" style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}>
                      <View
                        className="h-full rounded-full"
                        style={{
                          width: `${matchResult.romanticSpark.score}%`,
                          background: 'linear-gradient(90deg, #f093fb, #f5576c)',
                        }}
                      />
                    </View>
                  </View>

                  <View className="mb-4">
                    <Text className="text-white text-sm font-semibold mb-2 block">✨ 链接亮点</Text>
                    <View className="space-y-2">
                      {matchResult.romanticSpark.connectionHighlights.map((item: string, idx: number) => (
                        <View key={idx} className="flex items-start gap-2">
                          <View className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#f093fb' }} />
                          <Text className="text-xs flex-1 leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  <View className="mb-4">
                    <Text className="text-white text-sm font-semibold mb-2 block">⚠️ 潜在摩擦</Text>
                    <View className="space-y-2">
                      {matchResult.romanticSpark.potentialFrictions.map((item: string, idx: number) => (
                        <View key={idx} className="flex items-start gap-2">
                          <View className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#f59e0b' }} />
                          <Text className="text-xs flex-1 leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  <View>
                    <Text className="text-white text-sm font-semibold mb-2 block">💡 深化感情建议</Text>
                    <View className="space-y-2">
                      {matchResult.romanticSpark.deepeningAdvice.map((item: string, idx: number) => (
                        <View key={idx} className="flex items-start gap-2">
                          <View className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ backgroundColor: '#3b82f6' }} />
                          <Text className="text-xs flex-1 leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>
              )}
            </View>
          </View>
        )}

        {/* 底部版权信息 */}
        <View className="px-5 py-4 text-center">
          <Text className="text-xs font-medium block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
            PersonaLens: An Observation Project by Xingge
          </Text>
          <Text className="text-xs block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.5)' }}>
            For entertainment purposes only.
          </Text>
          <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.4)' }}>
            © 2026 Xingge. All rights reserved.
          </Text>
        </View>

        {/* 底部间距 */}
        <View className="h-6" />
      </ScrollView>
    </View>
  );
}
