export default definePageConfig({
  navigationBarTitleText: '匹配',
  navigationBarBackgroundColor: '#667eea',
  navigationBarTextStyle: 'white'
})
