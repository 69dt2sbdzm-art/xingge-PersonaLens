import { useState } from 'react';
import { View, Text, ScrollView } from '@tarojs/components';
import Taro, { useLoad } from '@tarojs/taro';
import { getAllTypeCodes, getTypeByCode, MBTI_TYPES } from '@/data/mbti-types';

export default function ExplorePage() {
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const typeCodes = getAllTypeCodes();

  useLoad(() => {
    console.log('探索页面加载完成');
  });

  const handleTypeSelect = (code: string) => {
    if (selectedType === code) {
      setSelectedType(null);
    } else {
      setSelectedType(code);
      // 延迟滚动到详情位置
      setTimeout(() => {
        Taro.createSelectorQuery()
          .select('#type-detail')
          .boundingClientRect((rect: any) => {
            if (rect) {
              Taro.pageScrollTo({
                scrollTop: rect.top - 80,
                duration: 300,
              });
            }
          })
          .exec();
      }, 100);
    }
  };

  // 按类别分组（带图标和毛玻璃背景）
  const categories = [
    {
      name: '分析家',
      types: ['INTJ', 'INTP', 'ENTJ', 'ENTP'],
      color: '#8b5cf6',
      icon: 'i-lucide-brain',
      bgGradient: 'linear-gradient(135deg, rgba(139, 92, 246, 0.35), rgba(167, 139, 250, 0.2))',
      borderColor: 'rgba(139, 92, 246, 0.4)',
      description: '理性思考者，追求知识与真理'
    },
    {
      name: '外交家',
      types: ['INFJ', 'INFP', 'ENFJ', 'ENFP'],
      color: '#10b981',
      icon: 'i-lucide-heart',
      bgGradient: 'linear-gradient(135deg, rgba(16, 185, 129, 0.35), rgba(52, 211, 153, 0.2))',
      borderColor: 'rgba(16, 185, 129, 0.4)',
      description: '理想主义者，重视情感与意义'
    },
    {
      name: '守护者',
      types: ['ISTJ', 'ISFJ', 'ESTJ', 'ESFJ'],
      color: '#3b82f6',
      icon: 'i-lucide-shield',
      bgGradient: 'linear-gradient(135deg, rgba(59, 130, 246, 0.35), rgba(96, 165, 250, 0.2))',
      borderColor: 'rgba(59, 130, 246, 0.4)',
      description: '务实可靠者，维护秩序与传统'
    },
    {
      name: '探险家',
      types: ['ISTP', 'ISFP', 'ESTP', 'ESFP'],
      color: '#f59e0b',
      icon: 'i-lucide-compass',
      bgGradient: 'linear-gradient(135deg, rgba(245, 158, 11, 0.35), rgba(251, 191, 36, 0.2))',
      borderColor: 'rgba(245, 158, 11, 0.4)',
      description: '自由行动派，享受当下与体验'
    },
  ];

  const selectedTypeInfo = selectedType ? getTypeByCode(selectedType) : null;

  // 获取选中类型所属类别
  const getSelectedCategory = () => {
    if (!selectedType) return null;
    for (const cat of categories) {
      if (cat.types.includes(selectedType)) return cat;
    }
    return null;
  };

  const selectedCategory = getSelectedCategory();

  return (
    <View className="min-h-screen" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)' }}>
      <ScrollView className="h-full" scrollY>
        {/* 标题区 */}
        <View className="px-5 pt-8 pb-4 text-center">
          <Text className="text-white text-2xl font-bold block mb-1">MBTI类型探索</Text>
          <Text className="text-sm" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>了解16种人格类型的特质</Text>
        </View>

        {/* 类型网格 - 按类别展示 */}
        <View className="px-5 space-y-4 mb-4">
          {categories.map((category) => (
            <View key={category.name}>
              {/* 类别标题卡片 - 毛玻璃效果 */}
              <View
                className="backdrop-blur-md border rounded-2xl p-3 mb-3"
                style={{
                  background: category.bgGradient,
                  borderColor: category.borderColor,
                }}
              >
                <View className="flex items-center gap-2 mb-1">
                  <View className={`${category.icon} w-5 h-5`} style={{ color: '#ffffff' }} />
                  <Text className="text-white text-sm font-bold">{category.name}</Text>
                </View>
                <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.75)' }}>{category.description}</Text>
              </View>

              {/* 类型网格 */}
              <View className="grid grid-cols-4 gap-2">
                {category.types.map((code) => {
                  const type = getTypeByCode(code);
                  const isSelected = selectedType === code;
                  return (
                    <View
                      key={code}
                      className="backdrop-blur-md border rounded-xl p-2 text-center"
                      style={{
                        backgroundColor: isSelected ? 'rgba(255, 255, 255, 0.3)' : 'rgba(255, 255, 255, 0.15)',
                        borderColor: isSelected ? category.color : 'rgba(255, 255, 255, 0.3)',
                        boxShadow: isSelected ? `0 0 12px ${category.color}40` : 'none',
                      }}
                      onClick={() => handleTypeSelect(code)}
                    >
                      <Text className={`text-xs font-bold block ${isSelected ? 'text-white' : ''}`} style={!isSelected ? { color: 'rgba(255, 255, 255, 0.8)' } : {}}>
                        {code}
                      </Text>
                      <Text className="block mt-1" style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '10px' }}>{type?.name}</Text>
                    </View>
                  );
                })}
              </View>

              {/* 选中类型的详情 - 全宽卡片插入到类别下方 */}
              {selectedType && selectedCategory === category && selectedTypeInfo && (
                <View id="type-detail" className="mt-4 space-y-3">
                  {/* 收起按钮栏 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-3 flex items-center justify-between"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      borderColor: category.color,
                    }}
                    onClick={() => setSelectedType(null)}
                  >
                    <View className="flex items-center gap-3">
                      <View
                        className="w-12 h-12 rounded-full flex items-center justify-center"
                        style={{
                          background: `linear-gradient(135deg, ${category.color}, ${category.color}cc)`,
                        }}
                      >
                        <Text className="text-white text-base font-bold">{selectedTypeInfo.code}</Text>
                      </View>
                      <View>
                        <Text className="text-white text-base font-bold block">{selectedTypeInfo.name}</Text>
                        <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{selectedTypeInfo.nickname}</Text>
                      </View>
                    </View>
                    <View className="flex items-center gap-1">
                      <Text className="text-sm" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>收起</Text>
                      <View className="i-lucide-chevron-up w-5 h-5" style={{ color: 'rgba(255, 255, 255, 0.8)' }} />
                    </View>
                  </View>

                  {/* 类型描述 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-sm leading-relaxed block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.description}</Text>
                  </View>

                  {/* 认知功能栈 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">认知功能栈</Text>
                    <View className="space-y-2">
                      {selectedTypeInfo.cognitiveFunctions.map((func, index) => (
                        <View key={index} className="flex items-center gap-3">
                          <View
                            className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{
                              backgroundColor: index === 0 ? 'rgba(139, 92, 246, 0.3)' : index === 1 ? 'rgba(59, 130, 246, 0.3)' : index === 2 ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)',
                            }}
                          >
                            <Text className="text-white text-xs font-bold">{func.code}</Text>
                          </View>
                          <View className="flex-1">
                            <Text className="text-white text-sm font-medium block">{func.name}</Text>
                            <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.65)' }}>{func.description}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  </View>

                  {/* 核心优势（多维） */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">核心优势</Text>
                    
                    <View className="space-y-3">
                      <View>
                        <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>思维维度</Text>
                        <View className="flex flex-wrap gap-2">
                          {selectedTypeInfo.strengths.thinking.map((item, idx) => (
                            <View key={idx} className="rounded-full px-3 py-1.5" style={{ backgroundColor: 'rgba(139, 92, 246, 0.2)' }}>
                              <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{item}</Text>
                            </View>
                          ))}
                        </View>
                      </View>

                      <View>
                        <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>工作风格</Text>
                        <View className="flex flex-wrap gap-2">
                          {selectedTypeInfo.strengths.working.map((item, idx) => (
                            <View key={idx} className="rounded-full px-3 py-1.5" style={{ backgroundColor: 'rgba(59, 130, 246, 0.2)' }}>
                              <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{item}</Text>
                            </View>
                          ))}
                        </View>
                      </View>

                      <View>
                        <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>人际互动</Text>
                        <View className="flex flex-wrap gap-2">
                          {selectedTypeInfo.strengths.interpersonal.map((item, idx) => (
                            <View key={idx} className="rounded-full px-3 py-1.5" style={{ backgroundColor: 'rgba(16, 185, 129, 0.2)' }}>
                              <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{item}</Text>
                            </View>
                          ))}
                        </View>
                      </View>

                      <View>
                        <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>创造力</Text>
                        <View className="flex flex-wrap gap-2">
                          {selectedTypeInfo.strengths.creative.map((item, idx) => (
                            <View key={idx} className="rounded-full px-3 py-1.5" style={{ backgroundColor: 'rgba(245, 158, 11, 0.2)' }}>
                              <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{item}</Text>
                            </View>
                          ))}
                        </View>
                      </View>
                    </View>
                  </View>

                  {/* 潜在盲区 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">潜在盲区</Text>
                    <View className="space-y-3">
                      {selectedTypeInfo.blindSpots.map((spot, index) => (
                        <View key={index} className="pb-3" style={{ borderBottom: index < selectedTypeInfo.blindSpots.length - 1 ? '1px solid rgba(255, 255, 255, 0.1)' : 'none' }}>
                          <Text className="text-white text-sm font-medium block mb-1">{spot.area}</Text>
                          <Text className="text-sm block mb-1.5" style={{ color: 'rgba(255, 255, 255, 0.75)' }}>{spot.description}</Text>
                          <Text className="text-sm" style={{ color: 'rgba(16, 185, 129, 0.85)' }}>💡 {spot.improvement}</Text>
                        </View>
                      ))}
                    </View>
                  </View>

                  {/* 亲密关系 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">亲密关系</Text>
                    <View className="space-y-2.5">
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(16, 185, 129, 0.85)' }}>✓ 优势</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.intimateRelationship.strength}</Text>
                      </View>
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(245, 158, 11, 0.85)' }}>⚠ 挑战</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.intimateRelationship.challenge}</Text>
                      </View>
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(59, 130, 246, 0.85)' }}>💡 建议</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.intimateRelationship.advice}</Text>
                      </View>
                    </View>
                  </View>

                  {/* 友谊模式 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">友谊模式</Text>
                    <View className="space-y-2.5">
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(16, 185, 129, 0.85)' }}>✓ 优势</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.friendship.strength}</Text>
                      </View>
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(245, 158, 11, 0.85)' }}>⚠ 挑战</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.friendship.challenge}</Text>
                      </View>
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(59, 130, 246, 0.85)' }}>💡 建议</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.friendship.advice}</Text>
                      </View>
                    </View>
                  </View>

                  {/* 职业发展 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">职业发展</Text>
                    <View className="space-y-2.5">
                      <View>
                        <Text className="text-sm font-medium block mb-2" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>最佳职业</Text>
                        <View className="flex flex-wrap gap-2">
                          {selectedTypeInfo.career.bestFit.map((job, idx) => (
                            <View key={idx} className="rounded-full px-3 py-1.5" style={{ backgroundColor: 'rgba(59, 130, 246, 0.2)' }}>
                              <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{job}</Text>
                            </View>
                          ))}
                        </View>
                      </View>
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>工作风格</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.career.workStyle}</Text>
                      </View>
                      <View>
                        <Text className="text-sm font-medium block mb-1" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>理想环境</Text>
                        <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>{selectedTypeInfo.career.environment}</Text>
                      </View>
                    </View>
                  </View>

                  {/* 最佳配对 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">最佳配对</Text>
                    <View className="space-y-2.5">
                      {selectedTypeInfo.bestMatches.map((match, index) => (
                        <View key={index} className="flex items-start gap-3 pb-2.5" style={{ borderBottom: index < selectedTypeInfo.bestMatches.length - 1 ? '1px solid rgba(255, 255, 255, 0.1)' : 'none' }}>
                          <View
                            className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{
                              backgroundColor: match.confidence === 'high' ? 'rgba(16, 185, 129, 0.3)' : match.confidence === 'medium' ? 'rgba(245, 158, 11, 0.3)' : 'rgba(239, 68, 68, 0.3)',
                            }}
                          >
                            <Text className="text-white text-xs font-bold">{match.type}</Text>
                          </View>
                          <View className="flex-1">
                            <Text className="text-white text-sm font-medium block">{getTypeByCode(match.type)?.name}</Text>
                            <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.75)' }}>{match.reason}</Text>
                            <Text className="text-xs mt-1 block" style={{ 
                              color: match.confidence === 'high' ? 'rgba(16, 185, 129, 0.85)' : match.confidence === 'medium' ? 'rgba(245, 158, 11, 0.85)' : 'rgba(239, 68, 68, 0.85)' 
                            }}>
                              可信度: {match.confidence === 'high' ? '高' : match.confidence === 'medium' ? '中' : '低'}
                            </Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  </View>

                  {/* 典型代表人物 */}
                  <View
                    className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.15)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white font-semibold mb-3 text-base block">典型代表人物</Text>
                    <View className="space-y-3.5">
                      {selectedTypeInfo.representatives.map((rep, index) => (
                        <View key={index} className="flex items-start gap-3">
                          <View
                            className="w-11 h-11 rounded-full flex-shrink-0 flex items-center justify-center"
                            style={{
                              background: 'linear-gradient(135deg, #667eea, #f093fb)',
                            }}
                          >
                            <Text className="text-white text-base font-bold">{rep.name.charAt(0)}</Text>
                          </View>
                          <View className="flex-1">
                            <Text className="text-white text-base font-medium block">{rep.name}</Text>
                            <Text className="text-sm block" style={{ color: 'rgba(255, 255, 255, 0.65)' }}>{rep.title}</Text>
                            <Text className="text-sm mt-1.5 block leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.75)' }}>{rep.description}</Text>
                            <View className="flex items-center gap-2 mt-1.5">
                              <Text className="text-xs" style={{ 
                                color: rep.confidence === 'verified' ? 'rgba(16, 185, 129, 0.85)' : rep.confidence === 'likely' ? 'rgba(245, 158, 11, 0.85)' : 'rgba(239, 68, 68, 0.85)' 
                              }}>
                                可信度: {rep.confidence === 'verified' ? '已验证' : rep.confidence === 'likely' ? '很可能' : '推测'}
                              </Text>
                              {rep.source && (
                                <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.5)' }}>来源: {rep.source}</Text>
                              )}
                            </View>
                          </View>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>
              )}
            </View>
          ))}
        </View>

        {/* 底部版权信息 */}
        <View className="px-5 py-4 text-center">
          <Text className="text-xs font-medium block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
            PersonaLens: An Observation Project by Xingge
          </Text>
          <Text className="text-xs block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.5)' }}>
            For entertainment purposes only.
          </Text>
          <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.4)' }}>
            © 2026 Xingge. All rights reserved.
          </Text>
        </View>

        {/* 底部间距 */}
        <View className="h-6" />
      </ScrollView>
    </View>
  );
}
