export default definePageConfig({
  navigationBarTitleText: '探索',
  navigationBarBackgroundColor: '#667eea',
  navigationBarTextStyle: 'white'
})
