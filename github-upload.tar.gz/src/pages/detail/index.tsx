import { useState } from 'react';
import { View, Text, ScrollView } from '@tarojs/components';
import Taro, { useLoad } from '@tarojs/taro';
import { getAllTypeCodes, getTypeByCode, MBTI_TYPES } from '@/data/mbti-types';

export default function DetailPage() {
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const typeCodes = getAllTypeCodes();

  useLoad(() => {
    console.log('类型探索页面加载完成');
  });

  const handleTypeSelect = (code: string) => {
    setSelectedType(code);
  };

  const selectedTypeInfo = selectedType ? getTypeByCode(selectedType) : null;

  return (
    <View className="min-h-screen" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)' }}>
      <ScrollView className="h-full" scrollY>
        {/* 标题区 */}
        <View className="px-5 pt-8 pb-4 text-center">
          <Text className="text-white text-2xl font-bold block mb-1">MBTI类型探索</Text>
          <Text className="text-sm" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>了解16种人格类型的特质</Text>
        </View>

        {/* 类型网格 */}
        <View className="px-5 mb-4">
          <View className="grid grid-cols-4 gap-2">
            {typeCodes.map((code) => {
              const type = getTypeByCode(code);
              const isSelected = selectedType === code;
              return (
                <View
                  key={code}
                  className="backdrop-blur-md border rounded-xl p-2 text-center"
                  style={{
                    backgroundColor: isSelected ? 'rgba(255, 255, 255, 0.25)' : 'rgba(255, 255, 255, 0.15)',
                    borderColor: isSelected ? 'rgba(255, 255, 255, 0.6)' : 'rgba(255, 255, 255, 0.3)',
                  }}
                  onClick={() => handleTypeSelect(code)}
                >
                  <Text className={`text-xs font-bold block ${isSelected ? 'text-white' : ''}`} style={!isSelected ? { color: 'rgba(255, 255, 255, 0.8)' } : {}}>
                    {code}
                  </Text>
                  <Text className="block mt-1" style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '10px' }}>{type?.name}</Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* 选中类型详情 */}
        {selectedTypeInfo && (
          <View className="px-5 space-y-4">
            {/* 类型卡片 */}
            <View
              className="backdrop-blur-md border rounded-2xl p-5 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              <View className="flex items-center gap-3 mb-3">
                <View
                  className="w-14 h-14 rounded-full flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, #667eea, #764ba2)',
                  }}
                >
                  <Text className="text-white text-xl font-bold">{selectedTypeInfo.code}</Text>
                </View>
                <View>
                  <Text className="text-white text-lg font-bold block">{selectedTypeInfo.name}</Text>
                  <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{selectedTypeInfo.nickname}</Text>
                </View>
              </View>
              <Text className="text-sm leading-relaxed block" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{selectedTypeInfo.description}</Text>
            </View>

            {/* 优势 */}
            <View
              className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              <Text className="text-white font-semibold mb-2 text-sm block">核心优势</Text>
              <View className="flex flex-wrap gap-2">
                {selectedTypeInfo.strengths.map((strength, index) => (
                  <View
                    key={index}
                    className="rounded-full px-3 py-1"
                    style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                  >
                    <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{strength}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* 待改进 */}
            <View
              className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              <Text className="text-white font-semibold mb-2 text-sm block">成长方向</Text>
              <View className="flex flex-wrap gap-2">
                {selectedTypeInfo.weaknesses.map((weakness, index) => (
                  <View
                    key={index}
                    className="rounded-full px-3 py-1"
                    style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                  >
                    <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>{weakness}</Text>
                  </View>
                ))}
              </View>
            </View>

            {/* 代表人物 */}
            <View
              className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.15)',
                borderColor: 'rgba(255, 255, 255, 0.3)',
              }}
            >
              <Text className="text-white font-semibold mb-3 text-sm block">典型代表</Text>
              <View className="space-y-3">
                {selectedTypeInfo.representatives.map((rep, index) => (
                  <View key={index} className="flex items-start gap-3">
                    <View
                      className="w-10 h-10 rounded-full flex-shrink-0 flex items-center justify-center"
                      style={{
                        background: 'linear-gradient(135deg, #667eea, #f093fb)',
                      }}
                    >
                      <Text className="text-white text-sm font-bold">{rep.name.charAt(0)}</Text>
                    </View>
                    <View className="flex-1">
                      <Text className="text-white text-sm font-medium block">{rep.name}</Text>
                      <Text className="text-xs block" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{rep.title}</Text>
                      <Text className="text-xs mt-1 block leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>{rep.description}</Text>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          </View>
        )}

        {/* 底部间距 */}
        <View className="h-6" />
      </ScrollView>
    </View>
  );
}
