export default definePageConfig({
  navigationBarTitleText: '类型探索'
})
