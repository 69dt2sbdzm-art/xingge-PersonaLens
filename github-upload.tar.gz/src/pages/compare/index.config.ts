export default definePageConfig({
  navigationBarTitleText: '比较',
  navigationBarBackgroundColor: '#667eea',
  navigationBarTextStyle: 'white'
})
