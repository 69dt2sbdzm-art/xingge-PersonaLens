import { useState } from 'react';
import { View, Text, Picker, ScrollView } from '@tarojs/components';
import Taro, { useLoad } from '@tarojs/taro';
import { getAllTypeCodes, getTypeByCode, MBTI_TYPES } from '@/data/mbti-types';

const typeOptions = getAllTypeCodes().map((code) => {
  const type = getTypeByCode(code);
  return { label: `${code} - ${type?.name}`, value: code };
});

export default function ComparePage() {
  const [type1, setType1] = useState('INTJ');
  const [type2, setType2] = useState('ENFP');

  useLoad(() => {
    console.log('比较页面加载完成');
  });

  const handleType1Change = (e: any) => {
    const index = Number(e.detail.value);
    setType1(typeOptions[index].value);
  };

  const handleType2Change = (e: any) => {
    const index = Number(e.detail.value);
    setType2(typeOptions[index].value);
  };

  const type1Info = getTypeByCode(type1);
  const type2Info = getTypeByCode(type2);

  if (!type1Info || !type2Info) {
    return null;
  }

  return (
    <View className="min-h-screen" style={{ background: 'linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%)' }}>
      <ScrollView className="h-full" scrollY>
        {/* 标题区 */}
        <View className="px-5 pt-8 pb-4 text-center">
          <Text className="text-white text-2xl font-bold block mb-1">MBTI类型比较</Text>
          <Text className="text-sm" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>深度对比两种人格特质</Text>
        </View>

        {/* 类型选择器 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <View className="flex items-center justify-between gap-3">
              {/* 类型1 */}
              <View className="flex-1">
                <Text className="text-xs mb-1 block" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>类型A</Text>
                <Picker mode="selector" range={typeOptions.map((o) => o.label)} onChange={handleType1Change}>
                  <View
                    className="w-full border rounded-xl px-3 py-2"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white text-sm">{typeOptions.find((o) => o.value === type1)?.label}</Text>
                  </View>
                </Picker>
              </View>

              {/* VS图标 */}
              <View
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #667eea, #f093fb)' }}
              >
                <Text className="text-white text-xs font-bold">VS</Text>
              </View>

              {/* 类型2 */}
              <View className="flex-1">
                <Text className="text-xs mb-1 block" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>类型B</Text>
                <Picker mode="selector" range={typeOptions.map((o) => o.label)} onChange={handleType2Change}>
                  <View
                    className="w-full border rounded-xl px-3 py-2"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.2)',
                      borderColor: 'rgba(255, 255, 255, 0.3)',
                    }}
                  >
                    <Text className="text-white text-sm">{typeOptions.find((o) => o.value === type2)?.label}</Text>
                  </View>
                </Picker>
              </View>
            </View>
          </View>
        </View>

        {/* 简单概述对比 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <Text className="text-white font-semibold mb-3 text-sm block">类型概述</Text>
            <View className="grid grid-cols-2 gap-3">
              {/* 类型1概述 */}
              <View>
                <View className="flex items-center gap-2 mb-2">
                  <View
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, #667eea, #764ba2)' }}
                  >
                    <Text className="text-white text-xs font-bold">{type1Info.code}</Text>
                  </View>
                  <Text className="text-white text-sm font-medium">{type1Info.name}</Text>
                </View>
                <Text className="text-xs leading-relaxed block" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{type1Info.description}</Text>
              </View>

              {/* 类型2概述 */}
              <View>
                <View className="flex items-center gap-2 mb-2">
                  <View
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, #f093fb, #f5576c)' }}
                  >
                    <Text className="text-white text-xs font-bold">{type2Info.code}</Text>
                  </View>
                  <Text className="text-white text-sm font-medium">{type2Info.name}</Text>
                </View>
                <Text className="text-xs leading-relaxed block" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{type2Info.description}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* 认知功能对比 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <Text className="text-white font-semibold mb-3 text-sm block">认知功能栈对比</Text>
            
            {/* 表头 */}
            <View className="grid grid-cols-3 gap-2 mb-2 pb-2" style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.2)' }}>
              <Text className="text-xs font-medium" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>功能层级</Text>
              <Text className="text-xs font-medium text-center" style={{ color: 'rgba(102, 126, 234, 0.9)' }}>{type1Info.code}</Text>
              <Text className="text-xs font-medium text-center" style={{ color: 'rgba(240, 147, 251, 0.9)' }}>{type2Info.code}</Text>
            </View>

            {/* 功能行 */}
            {['主导', '辅助', '第三', '劣势'].map((level, idx) => {
              const func1 = type1Info.cognitiveFunctions[idx];
              const func2 = type2Info.cognitiveFunctions[idx];
              return (
                <View key={idx} className="grid grid-cols-3 gap-2 mb-2 items-center">
                  <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>{level}</Text>
                  <View className="text-center">
                    <Text className="text-white text-xs font-bold block">{func1.code}</Text>
                    <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{func1.name}</Text>
                  </View>
                  <View className="text-center">
                    <Text className="text-white text-xs font-bold block">{func2.code}</Text>
                    <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{func2.name}</Text>
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* 核心优势对比 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <Text className="text-white font-semibold mb-3 text-sm block">核心优势对比</Text>
            
            <View className="grid grid-cols-2 gap-3">
              {/* 类型1优势 */}
              <View>
                <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(102, 126, 234, 0.9)' }}>{type1Info.name}的优势</Text>
                <View className="space-y-1.5">
                  {type1Info.strengths.thinking.slice(0, 2).map((item, idx) => (
                    <View key={idx} className="flex items-start gap-1.5">
                      <View className="w-1 h-1 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: '#667eea' }} />
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                    </View>
                  ))}
                  {type1Info.strengths.working.slice(0, 2).map((item, idx) => (
                    <View key={`w-${idx}`} className="flex items-start gap-1.5">
                      <View className="w-1 h-1 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: '#667eea' }} />
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                    </View>
                  ))}
                </View>
              </View>

              {/* 类型2优势 */}
              <View>
                <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(240, 147, 251, 0.9)' }}>{type2Info.name}的优势</Text>
                <View className="space-y-1.5">
                  {type2Info.strengths.thinking.slice(0, 2).map((item, idx) => (
                    <View key={idx} className="flex items-start gap-1.5">
                      <View className="w-1 h-1 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: '#f093fb' }} />
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                    </View>
                  ))}
                  {type2Info.strengths.working.slice(0, 2).map((item, idx) => (
                    <View key={`w-${idx}`} className="flex items-start gap-1.5">
                      <View className="w-1 h-1 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: '#f093fb' }} />
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{item}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* 潜在盲区对比 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <Text className="text-white font-semibold mb-3 text-sm block">潜在盲区对比</Text>
            
            <View className="grid grid-cols-2 gap-3">
              {/* 类型1盲区 */}
              <View>
                <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(102, 126, 234, 0.9)' }}>{type1Info.name}的盲区</Text>
                <View className="space-y-2">
                  {type1Info.blindSpots.slice(0, 2).map((spot, idx) => (
                    <View key={idx}>
                      <Text className="text-xs font-medium block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{spot.area}</Text>
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{spot.description}</Text>
                    </View>
                  ))}
                </View>
              </View>

              {/* 类型2盲区 */}
              <View>
                <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(240, 147, 251, 0.9)' }}>{type2Info.name}的盲区</Text>
                <View className="space-y-2">
                  {type2Info.blindSpots.slice(0, 2).map((spot, idx) => (
                    <View key={idx}>
                      <Text className="text-xs font-medium block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>{spot.area}</Text>
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{spot.description}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* 推荐职业方向 */}
        <View className="px-5 mb-4">
          <View
            className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.15)',
              borderColor: 'rgba(255, 255, 255, 0.3)',
            }}
          >
            <Text className="text-white font-semibold mb-3 text-sm block">推荐职业方向</Text>
            
            <View className="grid grid-cols-2 gap-3">
              {/* 类型1职业 */}
              <View>
                <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(102, 126, 234, 0.9)' }}>{type1Info.name}</Text>
                <View className="flex flex-wrap gap-1.5">
                  {type1Info.career.bestFit.slice(0, 4).map((job, idx) => (
                    <View key={idx} className="rounded-full px-2 py-1" style={{ backgroundColor: 'rgba(102, 126, 234, 0.2)' }}>
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{job}</Text>
                    </View>
                  ))}
                </View>
              </View>

              {/* 类型2职业 */}
              <View>
                <Text className="text-xs font-medium mb-2 block" style={{ color: 'rgba(240, 147, 251, 0.9)' }}>{type2Info.name}</Text>
                <View className="flex flex-wrap gap-1.5">
                  {type2Info.career.bestFit.slice(0, 4).map((job, idx) => (
                    <View key={idx} className="rounded-full px-2 py-1" style={{ backgroundColor: 'rgba(240, 147, 251, 0.2)' }}>
                      <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{job}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* 底部版权信息 */}
        <View className="px-5 py-4 text-center">
          <Text className="text-xs font-medium block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
            PersonaLens: An Observation Project by Xingge
          </Text>
          <Text className="text-xs block mb-0.5" style={{ color: 'rgba(255, 255, 255, 0.5)' }}>
            For entertainment purposes only.
          </Text>
          <Text className="text-xs" style={{ color: 'rgba(255, 255, 255, 0.4)' }}>
            © 2026 Xingge. All rights reserved.
          </Text>
        </View>

        {/* 底部间距 */}
        <View className="h-6" />
      </ScrollView>
    </View>
  );
}
