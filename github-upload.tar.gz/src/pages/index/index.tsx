import { useEffect } from 'react';
import Taro, { useLoad } from '@tarojs/taro';

export default function IndexPage() {
  useLoad(() => {
    console.log('首页加载完成');
    // 重定向到探索页
    Taro.switchTab({
      url: '/pages/explore/index'
    });
  });

  return null;
}
