export default definePageConfig({
  navigationBarTitleText: '人类观察计划',
  navigationBarBackgroundColor: '#667eea',
  navigationBarTextStyle: 'white'
})
