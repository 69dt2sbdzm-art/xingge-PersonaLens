/**
 * MBTI匹配度计算工具
 * 基于荣格心理类型理论和认知功能兼容性分析
 * 
 * 理论依据：
 * 1. Myers-Briggs Type Indicator (MBTI) 官方研究
 * 2. 认知功能栈理论 (Cognitive Function Stack)
 * 3. 类型动力学 (Type Dynamics)
 */

import { MBTI_TYPES, getDimensionValue } from '@/data/mbti-types';

export interface MatchResult {
  overallScore: number; // 总体匹配度 0-100
  dimensions: {
    EI: { score: number; description: string };
    SN: { score: number; description: string };
    TF: { score: number; description: string };
    JP: { score: number; description: string };
  };
  level: 'excellent' | 'good' | 'moderate' | 'challenging';
  summary: string;

  // 新增：工作兼容性分析
  workCompatibility: {
    score: number;
    collaborationStrengths: string[];
    potentialFrictions: string[];
    practicalAdvice: string[];
  };

  // 新增：感情火花值
  romanticSpark: {
    score: number;
    connectionHighlights: string[];
    potentialFrictions: string[];
    deepeningAdvice: string[];
  };
}

/**
 * 计算两个MBTI类型的匹配度
 * @param type1 第一个类型代码（如 "INTJ"）
 * @param type2 第二个类型代码（如 "ENFP"）
 * @returns 匹配度分析结果
 */
export function calculateMatch(type1: string, type2: string): MatchResult {
  const t1 = type1.toUpperCase();
  const t2 = type2.toUpperCase();

  // 验证类型有效性
  if (!MBTI_TYPES[t1] || !MBTI_TYPES[t2]) {
    throw new Error('无效的MBTI类型代码');
  }

  // 相同类型完美匹配
  if (t1 === t2) {
    const baseMatch: MatchResult = {
      overallScore: 95,
      dimensions: {
        EI: { score: 100, description: '完全一致的能量来源偏好' },
        SN: { score: 100, description: '完全一致的信息获取方式' },
        TF: { score: 100, description: '完全一致的决策风格' },
        JP: { score: 100, description: '完全一致的生活方式偏好' },
      },
      level: 'excellent',
      summary: '同类型配对，理解深刻但可能缺乏互补性',
      workCompatibility: {
        score: 95,
        collaborationStrengths: ['完全相同的思维模式，沟通零障碍', '工作节奏高度一致，协作流畅'],
        potentialFrictions: ['可能缺乏视角多样性，容易陷入思维盲区'],
        practicalAdvice: ['主动寻求外部意见，避免群体思维', '定期反思是否有盲点未被发现'],
      },
      romanticSpark: {
        score: 85,
        connectionHighlights: ['深层的理解和共鸣，无需过多解释', '相似的价值观和生活理念'],
        potentialFrictions: ['可能缺乏新鲜感和互补性', '双方都有相同的弱点需要克服'],
        deepeningAdvice: ['尝试新事物，为关系注入活力', '互相督促成长，弥补共同盲区'],
      },
    };
    return baseMatch;
  }

  // 计算各维度差异
  const eiDiff = getDimensionValue(t1, 'EI') !== getDimensionValue(t2, 'EI') ? 1 : 0;
  const snDiff = getDimensionValue(t1, 'SN') !== getDimensionValue(t2, 'SN') ? 1 : 0;
  const tfDiff = getDimensionValue(t1, 'TF') !== getDimensionValue(t2, 'TF') ? 1 : 0;
  const jpDiff = getDimensionValue(t1, 'JP') !== getDimensionValue(t2, 'JP') ? 1 : 0;

  const totalDiffs = eiDiff + snDiff + tfDiff + jpDiff;

  // 维度评分逻辑（基于类型动力学研究）
  // S/N维度最重要：相同的直觉/实感偏好意味着相似的认知方式
  // T/F次之：决策方式的兼容性影响沟通效率
  // E/I和J/P相对次要：可以通过互相适应来协调
  
  const dimensionScores = {
    EI: calculateEIScore(t1, t2, eiDiff),
    SN: calculateSNScore(t1, t2, snDiff),
    TF: calculateTFScore(t1, t2, tfDiff),
    JP: calculateJPScore(t1, t2, jpDiff),
  };

  // 加权计算总分
  // S/N权重最高(35%)，T/F次之(25%)，E/I和J/P各20%
  const overallScore = Math.round(
    dimensionScores.EI.score * 0.2 +
    dimensionScores.SN.score * 0.35 +
    dimensionScores.TF.score * 0.25 +
    dimensionScores.JP.score * 0.2
  );

  // 确定匹配等级
  let level: MatchResult['level'];
  if (overallScore >= 80) level = 'excellent';
  else if (overallScore >= 65) level = 'good';
  else if (overallScore >= 50) level = 'moderate';
  else level = 'challenging';

  // 生成总结
  const summary = generateSummary(t1, t2, overallScore, totalDiffs);

  // 创建临时match对象供子函数使用
  const match: MatchResult = {
    overallScore,
    dimensions: dimensionScores,
    level,
    summary,
    workCompatibility: { score: 0, collaborationStrengths: [], potentialFrictions: [], practicalAdvice: [] },
    romanticSpark: { score: 0, connectionHighlights: [], potentialFrictions: [], deepeningAdvice: [] },
  };

  // 计算工作兼容性
  const workCompatibility = calculateWorkCompatibility(t1, t2, match);

  // 计算感情火花值
  const romanticSpark = calculateRomanticSpark(t1, t2, match);

  return {
    overallScore,
    dimensions: dimensionScores,
    level,
    summary,
    workCompatibility,
    romanticSpark,
  };
}

/**
 * 计算E/I维度得分
 * 外向与内向的差异主要影响能量恢复方式，可通过互相尊重来协调
 */
function calculateEIScore(t1: string, t2: string, diff: number): { score: number; description: string } {
  if (diff === 0) {
    return {
      score: 90,
      description: '相同的能量来源偏好，彼此理解对方的社交需求',
    };
  }

  const eType = getDimensionValue(t1, 'EI') === 'E' ? t1 : t2;
  const iType = getDimensionValue(t1, 'EI') === 'I' ? t1 : t2;
  
  return {
    score: 65,
    description: `${eType}从社交获得能量，${iType}需要独处充电。建议平衡共同活动与个人空间`,
  };
}

/**
 * 计算S/N维度得分
 * 这是最重要的维度，决定了认知世界的根本方式
 * 相同的S/N偏好意味着相似的信息处理模式
 */
function calculateSNScore(t1: string, t2: string, diff: number): { score: number; description: string } {
  if (diff === 0) {
    const dim = getDimensionValue(t1, 'SN');
    if (dim === 'N') {
      return {
        score: 95,
        description: '同为直觉型，擅长抽象思维和未来规划，容易产生深度共鸣',
      };
    }
    return {
      score: 90,
      description: '同为实感型，关注具体事实和实际经验，沟通直接高效',
    };
  }

  return {
    score: 45,
    description: '直觉型关注可能性，实感型关注现实。需耐心解释各自的思维角度',
  };
}

/**
 * 计算T/F维度得分
 * 思考与情感的差异影响决策方式和冲突处理
 */
function calculateTFScore(t1: string, t2: string, diff: number): { score: number; description: string } {
  if (diff === 0) {
    const dim = getDimensionValue(t1, 'TF');
    if (dim === 'T') {
      return {
        score: 85,
        description: '同为思考型，重视逻辑分析和客观标准，决策效率高',
      };
    }
    return {
      score: 90,
      description: '同为情感型，重视人际和谐与价值观，共情能力强',
    };
  }

  return {
    score: 55,
    description: '思考型重逻辑，情感型重感受。需学习欣赏彼此的决策视角',
  };
}

/**
 * 计算J/P维度得分
 * 判断与知觉的差异影响生活节奏和计划性
 */
function calculateJPScore(t1: string, t2: string, diff: number): { score: number; description: string } {
  if (diff === 0) {
    const dim = getDimensionValue(t1, 'JP');
    if (dim === 'J') {
      return {
        score: 85,
        description: '同为判断型，偏好结构化生活，执行力强',
      };
    }
    return {
      score: 80,
      description: '同为知觉型，灵活开放，适应力强',
    };
  }

  return {
    score: 50,
    description: '判断型喜欢计划，知觉型偏好灵活。需协商生活和工作节奏',
  };
}

/**
 * 生成匹配总结
 */
function generateSummary(t1: string, t2: string, score: number, diffs: number): string {
  const type1Info = MBTI_TYPES[t1];
  const type2Info = MBTI_TYPES[t2];

  if (score >= 80) {
    return `${type1Info?.name}与${type2Info?.name}在认知方式和价值观上高度契合，是理想的合作伙伴或伴侣`;
  } else if (score >= 65) {
    return `${type1Info?.name}与${type2Info?.name}存在良好的互补性，通过有效沟通可以建立稳固关系`;
  } else if (score >= 50) {
    return `${type1Info?.name}与${type2Info?.name}在某些维度存在差异，需要更多理解和包容`;
  } else {
    return `${type1Info?.name}与${type2Info?.name}的认知方式差异较大，需要付出更多努力来相互理解`;
  }
}

/**
 * 获取关系建议
 * 基于类型组合提供工作、事业、情感三个维度的建议
 */
export function getRelationshipAdvice(type1: string, type2: string) {
  const t1 = type1.toUpperCase();
  const t2 = type2.toUpperCase();
  const match = calculateMatch(t1, t2);

  const type1Info = MBTI_TYPES[t1];
  const type2Info = MBTI_TYPES[t2];

  // 基础建议模板
  const adviceTemplates = {
    work: [
      `${type1Info?.name}的${getStrengthKeyword(t1)}与${type2Info?.name}的${getStrengthKeyword(t2)}形成互补`,
      '建议明确分工，让各自发挥优势',
      '建立定期沟通机制避免信息断层',
    ],
    career: [
      '适合在创意、咨询或教育领域合作',
      '共同学习新技能，拓展能力边界',
      '注意平衡理想主义与现实可行性',
    ],
    emotional: [
      '重视深度对话与精神共鸣',
      '尊重彼此的情感表达方式差异',
      '建立专属的"深度交流时间"',
    ],
  };

  // 根据匹配度调整建议
  if (match.level === 'excellent') {
    adviceTemplates.work.push('你们的天生默契使协作事半功倍');
    adviceTemplates.emotional.push('深层的精神连接是你们关系的基石');
  } else if (match.level === 'challenging') {
    adviceTemplates.work.unshift('需要更多耐心来理解对方的工作方式');
    adviceTemplates.emotional.unshift('学习欣赏彼此的差异而非试图改变对方');
  }

  return adviceTemplates;
}

/**
 * 获取类型的核心优势关键词
 */
function getStrengthKeyword(typeCode: string): string {
  const strengthsMap: Record<string, string> = {
    INTJ: '战略思维',
    INTP: '创新能力',
    ENTJ: '执行能力',
    ENTP: '创意思维',
    INFJ: '洞察力',
    INFP: '共情能力',
    ENFJ: '领导力',
    ENFP: '热情活力',
    ISTJ: '可靠性',
    ISFJ: '奉献精神',
    ESTJ: '组织能力',
    ESFJ: '亲和力',
    ISTP: '解决问题',
    ISFP: '艺术感知',
    ESTP: '行动力',
    ESFP: '感染力',
  };
  return strengthsMap[typeCode] || '独特优势';
}

/**
 * 计算工作兼容性
 * 基于认知功能互补性、工作风格匹配度分析
 */
function calculateWorkCompatibility(
  t1: string,
  t2: string,
  match: MatchResult
): MatchResult['workCompatibility'] {
  const type1Info = MBTI_TYPES[t1];
  const type2Info = MBTI_TYPES[t2];

  // 协作优势
  const collaborationStrengths: string[] = [];

  // S/N相同：沟通效率高
  if (getDimensionValue(t1, 'SN') === getDimensionValue(t2, 'SN')) {
    collaborationStrengths.push('相似的认知方式使信息传递高效准确');
  } else {
    collaborationStrengths.push(`${type1Info?.name}的${getDimensionValue(t1, 'SN') === 'N' ? '宏观视野' : '务实态度'}与${type2Info?.name}的${getDimensionValue(t2, 'SN') === 'N' ? '创新思维' : '执行细节'}形成互补`);
  }

  // T/F相同：决策风格一致
  if (getDimensionValue(t1, 'TF') === getDimensionValue(t2, 'TF')) {
    collaborationStrengths.push('相同的决策逻辑减少分歧，提高执行效率');
  } else {
    collaborationStrengths.push('思考型提供理性分析，情感型关注团队感受，决策更全面');
  }

  // J/P互补：计划与灵活平衡
  if (getDimensionValue(t1, 'JP') !== getDimensionValue(t2, 'JP')) {
    collaborationStrengths.push('判断型确保进度，知觉型应对变化，项目推进更稳健');
  }

  // 潜在摩擦
  const potentialFrictions: string[] = [];

  if (getDimensionValue(t1, 'JP') !== getDimensionValue(t2, 'JP')) {
    const jType = getDimensionValue(t1, 'JP') === 'J' ? t1 : t2;
    const pType = getDimensionValue(t1, 'JP') === 'P' ? t1 : t2;
    potentialFrictions.push(`${MBTI_TYPES[jType]?.name}可能觉得${MBTI_TYPES[pType]?.name}缺乏计划性，而后者可能感到被过度约束`);
  }

  if (getDimensionValue(t1, 'TF') !== getDimensionValue(t2, 'TF')) {
    const tType = getDimensionValue(t1, 'TF') === 'T' ? t1 : t2;
    const fType = getDimensionValue(t1, 'TF') === 'F' ? t1 : t2;
    potentialFrictions.push(`${MBTI_TYPES[tType]?.name}的直接逻辑可能被${MBTI_TYPES[fType]?.name}视为冷漠，需调整沟通方式`);
  }

  if (getDimensionValue(t1, 'EI') !== getDimensionValue(t2, 'EI')) {
    potentialFrictions.push('会议频率和沟通节奏可能存在差异，需要协商平衡点');
  }

  // 实践建议
  const practicalAdvice: string[] = [
    '建立明确的分工机制，让各自发挥认知优势',
    '定期复盘工作流程，及时调整协作模式',
  ];

  if (getDimensionValue(t1, 'JP') !== getDimensionValue(t2, 'JP')) {
    practicalAdvice.push('制定弹性时间表：核心节点明确，执行过程灵活');
  }

  if (getDimensionValue(t1, 'TF') !== getDimensionValue(t2, 'TF')) {
    practicalAdvice.push('重要决策时兼顾数据分析和团队感受两个维度');
  }

  // 计算工作兼容性分数（基于总体匹配度调整）
  let workScore = match.overallScore;

  // J/P相同加分（工作节奏一致）
  if (getDimensionValue(t1, 'JP') === getDimensionValue(t2, 'JP')) {
    workScore = Math.min(100, workScore + 5);
  }

  // T/F相同加分（决策风格一致）
  if (getDimensionValue(t1, 'TF') === getDimensionValue(t2, 'TF')) {
    workScore = Math.min(100, workScore + 3);
  }

  return {
    score: workScore,
    collaborationStrengths,
    potentialFrictions,
    practicalAdvice,
  };
}

/**
 * 计算感情火花值
 * 基于情感共鸣、吸引力、长期稳定性分析
 */
function calculateRomanticSpark(
  t1: string,
  t2: string,
  match: MatchResult
): MatchResult['romanticSpark'] {
  const type1Info = MBTI_TYPES[t1];
  const type2Info = MBTI_TYPES[t2];

  // 链接亮点
  const connectionHighlights: string[] = [];

  // N/N配对：精神共鸣强
  if (getDimensionValue(t1, 'SN') === 'N' && getDimensionValue(t2, 'SN') === 'N') {
    connectionHighlights.push('深层的精神对话和思想碰撞产生强烈吸引力');
  }

  // E/I互补：能量平衡
  if (getDimensionValue(t1, 'EI') !== getDimensionValue(t2, 'EI')) {
    connectionHighlights.push('外向方带来活力，内向方提供深度，关系充满张力');
  }

  // F/F配对：情感连接深
  if (getDimensionValue(t1, 'TF') === 'F' && getDimensionValue(t2, 'TF') === 'F') {
    connectionHighlights.push('高度的情感共鸣和相互理解，亲密感强');
  }

  // T/F互补：成长空间大
  if (getDimensionValue(t1, 'TF') !== getDimensionValue(t2, 'TF')) {
    connectionHighlights.push('理性与感性的碰撞促进双方共同成长');
  }

  // 潜在摩擦
  const potentialFrictions: string[] = [];

  if (getDimensionValue(t1, 'TF') !== getDimensionValue(t2, 'TF')) {
    const tType = getDimensionValue(t1, 'TF') === 'T' ? t1 : t2;
    const fType = getDimensionValue(t1, 'TF') === 'F' ? t1 : t2;
    potentialFrictions.push(`${MBTI_TYPES[tType]?.name}可能忽视情感需求，${MBTI_TYPES[fType]?.name}可能过度敏感`);
  }

  if (getDimensionValue(t1, 'JP') !== getDimensionValue(t2, 'JP')) {
    potentialFrictions.push('生活节奏差异可能导致日常摩擦，如约会计划、家务安排等');
  }

  if (getDimensionValue(t1, 'SN') !== getDimensionValue(t2, 'SN')) {
    potentialFrictions.push('一个关注未来可能性，一个关注当下现实，话题可能错位');
  }

  // 深化感情建议
  const deepeningAdvice: string[] = [
    '创造专属的"深度交流时间"，分享内心真实想法',
    '学习对方的"爱的语言"，用对方能接收的方式表达关心',
  ];

  if (getDimensionValue(t1, 'TF') !== getDimensionValue(t2, 'TF')) {
    deepeningAdvice.push('思考型学习表达情感，情感型学习理性分析问题');
  }

  if (getDimensionValue(t1, 'EI') !== getDimensionValue(t2, 'EI')) {
    deepeningAdvice.push('尊重彼此的能量恢复方式：社交活动与独处时间平衡');
  }

  // 计算感情火花分数
  let sparkScore = match.overallScore;

  // N/N配对加分（精神共鸣）
  if (getDimensionValue(t1, 'SN') === 'N' && getDimensionValue(t2, 'SN') === 'N') {
    sparkScore = Math.min(100, sparkScore + 8);
  }

  // E/I互补加分（吸引力）
  if (getDimensionValue(t1, 'EI') !== getDimensionValue(t2, 'EI')) {
    sparkScore = Math.min(100, sparkScore + 5);
  }

  // F/F配对加分（情感连接）
  if (getDimensionValue(t1, 'TF') === 'F' && getDimensionValue(t2, 'TF') === 'F') {
    sparkScore = Math.min(100, sparkScore + 6);
  }

  // S/S配对减分（可能缺乏新鲜感）
  if (getDimensionValue(t1, 'SN') === 'S' && getDimensionValue(t2, 'SN') === 'S') {
    sparkScore = Math.max(0, sparkScore - 3);
  }

  return {
    score: sparkScore,
    connectionHighlights,
    potentialFrictions,
    deepeningAdvice,
  };
}
