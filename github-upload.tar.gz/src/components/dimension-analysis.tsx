import { View, Text } from '@tarojs/components';

interface DimensionData {
  score: number;
  description: string;
}

interface DimensionAnalysisProps {
  dimensions: {
    EI: DimensionData;
    SN: DimensionData;
    TF: DimensionData;
    JP: DimensionData;
  };
}

const dimensionLabels = {
  EI: { left: 'E 外向', right: 'I 内向' },
  SN: { left: 'S 实感', right: 'N 直觉' },
  TF: { left: 'T 思考', right: 'F 情感' },
  JP: { left: 'J 判断', right: 'P 知觉' },
};

export default function DimensionAnalysis({ dimensions }: DimensionAnalysisProps) {
  return (
    <View
      className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.15)',
        borderColor: 'rgba(255, 255, 255, 0.3)',
      }}
    >
      <Text className="text-white font-semibold mb-3 text-sm block">四维差异解析</Text>
      
      <View className="space-y-3">
        {/* E/I 维度 */}
        <View>
          <View className="flex justify-between text-xs mb-1" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>
            <Text>{dimensionLabels.EI.left}</Text>
            <Text>{dimensionLabels.EI.right}</Text>
          </View>
          <View
            className="h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
          >
            <View
              className="h-full rounded-full"
              style={{
                width: `${dimensions.EI.score}%`,
                background: 'linear-gradient(90deg, #667eea, #764ba2)',
              }}
            />
          </View>
          <Text className="text-xs mt-1 block" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{dimensions.EI.description}</Text>
        </View>

        {/* S/N 维度 */}
        <View>
          <View className="flex justify-between text-xs mb-1" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>
            <Text>{dimensionLabels.SN.left}</Text>
            <Text>{dimensionLabels.SN.right}</Text>
          </View>
          <View
            className="h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
          >
            <View
              className="h-full rounded-full"
              style={{
                width: `${dimensions.SN.score}%`,
                background: 'linear-gradient(90deg, #667eea, #764ba2)',
              }}
            />
          </View>
          <Text className="text-xs mt-1 block" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{dimensions.SN.description}</Text>
        </View>

        {/* T/F 维度 */}
        <View>
          <View className="flex justify-between text-xs mb-1" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>
            <Text>{dimensionLabels.TF.left}</Text>
            <Text>{dimensionLabels.TF.right}</Text>
          </View>
          <View
            className="h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
          >
            <View
              className="h-full rounded-full"
              style={{
                width: `${dimensions.TF.score}%`,
                background: 'linear-gradient(90deg, #667eea, #764ba2)',
              }}
            />
          </View>
          <Text className="text-xs mt-1 block" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{dimensions.TF.description}</Text>
        </View>

        {/* J/P 维度 */}
        <View>
          <View className="flex justify-between text-xs mb-1" style={{ color: 'rgba(255, 255, 255, 0.8)' }}>
            <Text>{dimensionLabels.JP.left}</Text>
            <Text>{dimensionLabels.JP.right}</Text>
          </View>
          <View
            className="h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.2)' }}
          >
            <View
              className="h-full rounded-full"
              style={{
                width: `${dimensions.JP.score}%`,
                background: 'linear-gradient(90deg, #667eea, #764ba2)',
              }}
            />
          </View>
          <Text className="text-xs mt-1 block" style={{ color: 'rgba(255, 255, 255, 0.6)' }}>{dimensions.JP.description}</Text>
        </View>
      </View>
    </View>
  );
}
