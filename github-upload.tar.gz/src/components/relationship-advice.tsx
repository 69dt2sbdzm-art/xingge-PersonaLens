import { View, Text } from '@tarojs/components';

interface RelationshipAdviceProps {
  advice: {
    work: string[];
    career: string[];
    emotional: string[];
  };
  activeTab: 'work' | 'career' | 'emotional';
  onTabChange: (tab: 'work' | 'career' | 'emotional') => void;
}

const tabLabels = {
  work: '工作协作',
  career: '事业发展',
  emotional: '情感链接',
};

export default function RelationshipAdvice({ advice, activeTab, onTabChange }: RelationshipAdviceProps) {
  const currentAdvice = advice[activeTab];

  return (
    <View
      className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.15)',
        borderColor: 'rgba(255, 255, 255, 0.3)',
      }}
    >
      {/* Tab切换 */}
      <View className="flex gap-2 mb-3">
        {(['work', 'career', 'emotional'] as const).map((tab) => (
          <View
            key={tab}
            className="flex-1 py-2 rounded-lg text-xs font-medium text-center"
            style={{
              backgroundColor: activeTab === tab ? 'rgba(255, 255, 255, 0.25)' : 'transparent',
              color: activeTab === tab ? '#ffffff' : 'rgba(255, 255, 255, 0.6)',
            }}
            onClick={() => onTabChange(tab)}
          >
            {tabLabels[tab]}
          </View>
        ))}
      </View>

      {/* 建议内容 */}
      <View className="space-y-2">
        {currentAdvice.map((item, index) => (
          <View
            key={index}
            className="rounded-xl p-3"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
          >
            <Text className="text-xs leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.9)' }}>{item}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}
