import { View, Text } from '@tarojs/components';
import type { MBTIType } from '@/data/mbti-types';

interface RepresentativeFiguresProps {
  type1: MBTIType;
  type2: MBTIType;
}

export default function RepresentativeFigures({ type1, type2 }: RepresentativeFiguresProps) {
  const allRepresentatives = [...type1.representatives, ...type2.representatives];

  return (
    <View
      className="backdrop-blur-md border rounded-2xl p-4 shadow-lg"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.15)',
        borderColor: 'rgba(255, 255, 255, 0.3)',
      }}
    >
      <Text className="text-white font-semibold mb-3 text-sm block">典型代表人物</Text>
      
      <View className="space-y-3">
        {allRepresentatives.map((rep, index) => {
          const typeCode = getTypeCodeFromRep(rep, type1, type2);
          return (
            <View key={index} className="flex items-start gap-3">
              {/* 头像 */}
              <View
                className="w-12 h-12 rounded-full flex-shrink-0 flex items-center justify-center"
                style={{
                  background: 'linear-gradient(135deg, #667eea, #f093fb)',
                }}
              >
                <Text className="text-white text-lg font-bold">{rep.name.charAt(0)}</Text>
              </View>
              
              {/* 信息 */}
              <View className="flex-1">
                <Text className="text-white text-sm font-medium block">{rep.name}</Text>
                <Text className="text-xs block mt-1" style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: '10px' }}>
                  {rep.title} · {typeCode}
                </Text>
                <Text className="text-xs mt-1 block leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.7)' }}>
                  {rep.description}
                </Text>
              </View>
            </View>
          );
        })}
      </View>
    </View>
  );
}

// 辅助函数：根据代表人物找到对应的类型代码
function getTypeCodeFromRep(rep: any, type1: any, type2: any): string {
  const isInType1 = type1.representatives.some((r: any) => r.name === rep.name);
  return isInType1 ? type1.code : type2.code;
}
