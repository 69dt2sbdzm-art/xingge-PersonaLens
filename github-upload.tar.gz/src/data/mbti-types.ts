/**
 * MBTI 16种人格类型完整数据
 * 基于Myers-Briggs Type Indicator官方理论框架和认知功能栈理论
 * 
 * 数据来源：
 * - The Myers & Briggs Foundation
 * - Personality Hacker (认知功能栈)
 * - TypeLogic (类型动力学)
 */

export interface CognitiveFunction {
  name: string;
  code: string;
  description: string;
}

export interface DimensionalStrength {
  category: string;
  items: string[];
}

export interface BlindSpot {
  area: string;
  description: string;
  improvement: string;
}

export interface RelationshipInsight {
  strength: string;
  challenge: string;
  advice: string;
}

export interface CareerInfo {
  bestFit: string[];
  workStyle: string;
  environment: string;
}

export interface BestMatch {
  type: string;
  reason: string;
  confidence: 'high' | 'medium' | 'low';
}

export interface RepresentativeFigure {
  name: string;
  title: string;
  description: string;
  confidence: 'verified' | 'likely' | 'speculative';
  source?: string;
}

export interface MBTIType {
  code: string;
  name: string;
  nickname: string;
  dimensions: {
    EI: 'E' | 'I';
    SN: 'S' | 'N';
    TF: 'T' | 'F';
    JP: 'J' | 'P';
  };
  description: string;
  
  // 认知功能栈（从主导到劣势）
  cognitiveFunctions: CognitiveFunction[];
  
  // 核心优势（多维度）
  strengths: {
    thinking: string[];
    working: string[];
    interpersonal: string[];
    creative: string[];
  };
  
  // 潜在盲区
  blindSpots: BlindSpot[];
  
  // 亲密关系洞察
  intimateRelationship: RelationshipInsight;
  
  // 友谊模式
  friendship: RelationshipInsight;
  
  // 职业发展
  career: CareerInfo;
  
  // 最佳配对
  bestMatches: BestMatch[];
  
  // 典型代表人物（带可信度）
  representatives: RepresentativeFigure[];
}

// 四个维度定义
export const DIMENSIONS: Record<string, { code: string; name: string; description: string }> = {
  E: { code: 'E', name: '外向', description: '从外部世界和社交互动中获得能量' },
  I: { code: 'I', name: '内向', description: '从内部思考和独处中获得能量' },
  S: { code: 'S', name: '实感', description: '关注具体事实和实际经验' },
  N: { code: 'N', name: '直觉', description: '关注抽象概念和未来可能性' },
  T: { code: 'T', name: '思考', description: '基于逻辑和客观分析做决策' },
  F: { code: 'F', name: '情感', description: '基于价值观和人际和谐做决策' },
  J: { code: 'J', name: '判断', description: '偏好结构化、有计划的生活方式' },
  P: { code: 'P', name: '知觉', description: '偏好灵活、开放的生活方式' },
};

// 16种人格类型完整数据
export const MBTI_TYPES: Record<string, MBTIType> = {
  // ==================== 分析家类型 (NT) ====================
  
  INTJ: {
    code: 'INTJ',
    name: '建筑师',
    nickname: 'The Architect',
    dimensions: { EI: 'I', SN: 'N', TF: 'T', JP: 'J' },
    description: '富有想象力和战略性的思想家，一切皆在计划之中。独立、果断，具有强烈的求知欲和长远眼光。',
    
    cognitiveFunctions: [
      { name: '内向直觉', code: 'Ni', description: '主导功能：洞察模式和未来可能性' },
      { name: '外向思考', code: 'Te', description: '辅助功能：高效组织和执行' },
      { name: '内向情感', code: 'Fi', description: '第三功能：个人价值观体系' },
      { name: '外向实感', code: 'Se', description: '劣势功能：当下感官体验' },
    ],
    
    strengths: {
      thinking: ['战略思维', '系统分析', '长远规划'],
      working: ['独立自主', '高标准', '执行力强'],
      interpersonal: ['诚实直接', '忠诚可靠'],
      creative: ['创新解决方案', '概念整合'],
    },
    
    blindSpots: [
      { area: '情感表达', description: '难以表达和理解他人情感需求', improvement: '练习主动倾听和情感回应' },
      { area: '细节关注', description: '可能忽视执行中的细节问题', improvement: '建立检查清单或与S型搭档' },
      { area: '灵活性', description: '过于坚持既定计划', improvement: '预留调整空间，接受不确定性' },
    ],
    
    intimateRelationship: {
      strength: '忠诚且致力于长期关系建设',
      challenge: '可能显得情感疏离，需要学习表达感受',
      advice: '定期安排深度对话时间，主动分享内心想法',
    },
    
    friendship: {
      strength: '提供深刻的见解和可靠的建议',
      challenge: '社交精力有限，可能显得冷淡',
      advice: '明确表达重视，即使不能频繁联系',
    },
    
    career: {
      bestFit: ['战略规划师', '系统架构师', '研究科学家', '管理顾问', '投资分析师'],
      workStyle: '喜欢独立工作，追求效率和系统性',
      environment: '结构化但有智力挑战的环境',
    },
    
    bestMatches: [
      { type: 'ENFP', reason: 'ENFP的创造力与INTJ的战略思维形成完美互补', confidence: 'high' },
      { type: 'ENTP', reason: '共同的直觉和思考偏好，激发智力碰撞', confidence: 'high' },
      { type: 'INFJ', reason: '共享直觉主导，深层精神共鸣', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '埃隆·马斯克', title: '企业家', description: '特斯拉和SpaceX创始人，以长远愿景著称', confidence: 'likely', source: '公开行为分析' },
      { name: '克里斯托弗·诺兰', title: '电影导演', description: '《盗梦空间》导演，复杂叙事结构大师', confidence: 'likely', source: '创作风格分析' },
      { name: '弗里德里希·尼采', title: '哲学家', description: '以系统性哲学思考影响后世', confidence: 'speculative', source: '著作风格推断' },
    ],
  },

  INTP: {
    code: 'INTP',
    name: '逻辑学家',
    nickname: 'The Logician',
    dimensions: { EI: 'I', SN: 'N', TF: 'T', JP: 'P' },
    description: '具有创造力的发明家，对知识有着永不满足的渴求。善于发现模式，热爱理论探讨。',
    
    cognitiveFunctions: [
      { name: '内向思考', code: 'Ti', description: '主导功能：内部逻辑分析' },
      { name: '外向直觉', code: 'Ne', description: '辅助功能：探索可能性' },
      { name: '内向实感', code: 'Si', description: '第三功能：经验积累' },
      { name: '外向情感', code: 'Fe', description: '劣势功能：群体和谐' },
    ],
    
    strengths: {
      thinking: ['分析能力强', '原创思维', '客观理性'],
      working: ['问题解决', '概念创新', '独立思考'],
      interpersonal: ['思想开放', '诚实直接'],
      creative: ['理论构建', '模式识别'],
    },
    
    blindSpots: [
      { area: '执行落地', description: '想法多但实施困难', improvement: '设定具体截止日期' },
      { area: '情感敏感', description: '可能无意中伤害他人感受', improvement: '注意措辞和语气' },
      { area: '常规事务', description: '厌恶重复性工作', improvement: '自动化或委托处理' },
    ],
    
    intimateRelationship: {
      strength: '尊重伴侣独立性，提供智力刺激',
      challenge: '可能忽视情感需求和日常关怀',
      advice: '学习用对方理解的方式表达关心',
    },
    
    friendship: {
      strength: '有趣的对话伙伴，乐于分享知识',
      challenge: '可能忘记维持联系',
      advice: '设置提醒定期问候朋友',
    },
    
    career: {
      bestFit: ['软件工程师', '数据科学家', '研究员', '哲学家', '系统分析师'],
      workStyle: '喜欢自主探索，讨厌微观管理',
      environment: '允许自由思考和实验的环境',
    },
    
    bestMatches: [
      { type: 'ENTJ', reason: 'ENTJ的执行能力弥补INTP的实施短板', confidence: 'high' },
      { type: 'ENFJ', reason: 'ENFJ的情感智慧平衡INTP的逻辑倾向', confidence: 'medium' },
      { type: 'INFJ', reason: '共同的直觉和思考深度', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '阿尔伯特·爱因斯坦', title: '物理学家', description: '相对论创立者，好奇心驱动的科学探索', confidence: 'likely', source: '传记和行为记录' },
      { name: '比尔·盖茨', title: '微软创始人', description: '系统化思维解决全球问题', confidence: 'likely', source: '公开访谈分析' },
      { name: '艾萨克·牛顿', title: '科学家', description: '经典力学奠基人', confidence: 'speculative', source: '历史文献推断' },
    ],
  },

  ENTJ: {
    code: 'ENTJ',
    name: '指挥官',
    nickname: 'The Commander',
    dimensions: { EI: 'E', SN: 'N', TF: 'T', JP: 'J' },
    description: '大胆、富有想象力且意志强大的领导者，总是能找到或创造解决方法。天生具有领导才能。',
    
    cognitiveFunctions: [
      { name: '外向思考', code: 'Te', description: '主导功能：高效组织和决策' },
      { name: '内向直觉', code: 'Ni', description: '辅助功能：长远愿景' },
      { name: '外向实感', code: 'Se', description: '第三功能：当下行动' },
      { name: '内向情感', code: 'Fi', description: '劣势功能：个人价值观' },
    ],
    
    strengths: {
      thinking: ['战略眼光', '决断力', '系统思维'],
      working: ['高效执行', '组织能力', '目标导向'],
      interpersonal: ['自信果断', '激励他人'],
      creative: ['创新策略', '资源整合'],
    },
    
    blindSpots: [
      { area: '情感体谅', description: '可能显得专断和缺乏同理心', improvement: '练习换位思考' },
      { area: '耐心', description: '对低效率容忍度低', improvement: '理解不同工作节奏' },
      { area: '接受反馈', description: '可能抗拒批评', improvement: '主动寻求建设性意见' },
    ],
    
    intimateRelationship: {
      strength: '致力于关系成长，提供稳定性和方向',
      challenge: '可能过度控制，忽视伴侣感受',
      advice: '学习倾听而非总是给出解决方案',
    },
    
    friendship: {
      strength: '可靠的朋友，愿意提供帮助和建议',
      challenge: '可能把友谊当作网络建设',
      advice: '区分功利性和纯粹友谊',
    },
    
    career: {
      bestFit: ['CEO', '管理顾问', '律师', '项目经理', '企业家'],
      workStyle: '喜欢领导和决策，追求效率',
      environment: '有明确目标和晋升路径的组织',
    },
    
    bestMatches: [
      { type: 'INTP', reason: 'INTP的分析能力补充ENTJ的执行导向', confidence: 'high' },
      { type: 'INFP', reason: 'INFP的价值观平衡ENTJ的实用主义', confidence: 'medium' },
      { type: 'ISTP', reason: '共同的思考偏好，务实合作', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '史蒂夫·乔布斯', title: '苹果联合创始人', description: '以远见和完美主义重新定义科技', confidence: 'likely', source: '传记和管理风格' },
      { name: '玛格丽特·撒切尔', title: '英国前首相', description: '铁娘子，坚定果断的政治领袖', confidence: 'likely', source: '政治生涯分析' },
      { name: '戈登·拉姆齐', title: '厨师/电视名人', description: '高标准和直接风格的代表', confidence: 'speculative', source: '公众形象分析' },
    ],
  },

  ENTP: {
    code: 'ENTP',
    name: '辩论家',
    nickname: 'The Debater',
    dimensions: { EI: 'E', SN: 'N', TF: 'T', JP: 'P' },
    description: '聪明好奇的思想者，无法抵挡智力挑战的诱惑。喜欢探索新想法，享受辩论过程。',
    
    cognitiveFunctions: [
      { name: '外向直觉', code: 'Ne', description: '主导功能：探索可能性' },
      { name: '内向思考', code: 'Ti', description: '辅助功能：逻辑分析' },
      { name: '外向情感', code: 'Fe', description: '第三功能：社交魅力' },
      { name: '内向实感', code: 'Si', description: '劣势功能：细节和常规' },
    ],
    
    strengths: {
      thinking: ['机智幽默', '知识广博', '创新思维'],
      working: ['适应力强', '快速学习', '问题解决'],
      interpersonal: ['魅力四射', '善于辩论'],
      creative: ['创意发散', '跨界联想'],
    },
    
    blindSpots: [
      { area: '专注力', description: '容易从一个项目跳到另一个', improvement: '设定优先级和截止日' },
      { area: '承诺', description: '可能回避长期承诺', improvement: '从小承诺开始建立信任' },
      { area: '敏感性', description: '辩论时可能忽视他人感受', improvement: '注意场合和对象' },
    ],
    
    intimateRelationship: {
      strength: '充满活力的伴侣，保持关系新鲜感',
      challenge: '可能显得不可靠或不专注',
      advice: '用行动证明承诺，而不仅是言语',
    },
    
    friendship: {
      strength: '有趣的聊天对象，带来新视角',
      challenge: '可能争论过多',
      advice: '学会何时停止辩论',
    },
    
    career: {
      bestFit: ['创业者', '律师', '咨询师', '营销专家', '产品经理'],
      workStyle: '喜欢多样性和挑战，讨厌例行公事',
      environment: '鼓励创新和辩论的文化',
    },
    
    bestMatches: [
      { type: 'INTJ', reason: 'INTJ的深度思考与ENTP的广度探索互补', confidence: 'high' },
      { type: 'INFJ', reason: 'INFJ的深度平衡ENTP的广度', confidence: 'medium' },
      { type: 'ISFJ', reason: 'ISFJ的稳定性平衡ENTP的变化性', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '马克·吐温', title: '作家', description: '以讽刺幽默和敏锐洞察力闻名', confidence: 'likely', source: '写作风格分析' },
      { name: '托马斯·爱迪生', title: '发明家', description: '不断尝试和创新的精神', confidence: 'speculative', source: '工作方式推断' },
      { name: '小罗伯特·唐尼', title: '演员', description: '机智和即兴表演能力', confidence: 'speculative', source: '采访和角色选择' },
    ],
  },

  // ==================== 外交家类型 (NF) ====================
  
  INFJ: {
    code: 'INFJ',
    name: '提倡者',
    nickname: 'The Advocate',
    dimensions: { EI: 'I', SN: 'N', TF: 'F', JP: 'J' },
    description: '安静而神秘，同时鼓舞人心且不知疲倦的理想主义者。具有深刻的洞察力和强烈的使命感。',
    
    cognitiveFunctions: [
      { name: '内向直觉', code: 'Ni', description: '主导功能：洞察深层意义' },
      { name: '外向情感', code: 'Fe', description: '辅助功能：理解他人情感' },
      { name: '内向思考', code: 'Ti', description: '第三功能：内部逻辑分析' },
      { name: '外向实感', code: 'Se', description: '劣势功能：当下体验' },
    ],
    
    strengths: {
      thinking: ['富有洞察力', '理想主义', '创造力强'],
      working: ['热情奉献', '决断力', '组织能力'],
      interpersonal: ['共情能力强', '善于倾听', '真诚关怀'],
      creative: ['象征性思维', '人文关怀'],
    },
    
    blindSpots: [
      { area: '完美主义', description: '对自己和他人要求过高', improvement: '接受不完美是人性的一部分' },
      { area: '倦怠', description: '过度付出导致精力耗尽', improvement: '设定边界，学会说不' },
      { area: '冲突回避', description: '为避免冲突而压抑自己', improvement: '学习健康地表达分歧' },
    ],
    
    intimateRelationship: {
      strength: '深度连接，致力于伴侣成长',
      challenge: '可能过度理想化关系',
      advice: '接受关系中的不完美，专注于真实连接',
    },
    
    friendship: {
      strength: '忠诚且深刻的朋友',
      challenge: '朋友圈小，需要大量独处时间',
      advice: '提前沟通自己的社交需求',
    },
    
    career: {
      bestFit: ['心理咨询师', '作家', '教师', '人力资源', '非营利组织'],
      workStyle: '追求有意义的工作，重视价值观契合',
      environment: '支持个人成长和助人理念的环境',
    },
    
    bestMatches: [
      { type: 'ENFP', reason: 'ENFP的热情激活INFJ的理想主义', confidence: 'high' },
      { type: 'ENTP', reason: 'ENTP的思维挑战激发INFJ的深度', confidence: 'medium' },
      { type: 'INTJ', reason: '共享直觉主导，深层理解', confidence: 'high' },
    ],
    
    representatives: [
      { name: '纳尔逊·曼德拉', title: '南非前总统', description: '以远见和人文关怀推动和解', confidence: 'likely', source: '领导和演讲风格' },
      { name: '马丁·路德·金', title: '民权运动领袖', description: '以梦想和道德感召力激励变革', confidence: 'likely', source: '演讲和著作分析' },
      { name: 'Lady Gaga', title: '歌手/演员', description: '以自我表达和社会倡导闻名', confidence: 'speculative', source: '公开言论分析' },
    ],
  },

  INFP: {
    code: 'INFP',
    name: '调停者',
    nickname: 'The Mediator',
    dimensions: { EI: 'I', SN: 'N', TF: 'F', JP: 'P' },
    description: '诗意、善良的利他主义者，总是热情地为正当理由提供帮助。重视内心真实和道德准则。',
    
    cognitiveFunctions: [
      { name: '内向情感', code: 'Fi', description: '主导功能：个人价值观体系' },
      { name: '外向直觉', code: 'Ne', description: '辅助功能：探索可能性' },
      { name: '内向实感', code: 'Si', description: '第三功能：经验回顾' },
      { name: '外向思考', code: 'Te', description: '劣势功能：外部组织' },
    ],
    
    strengths: {
      thinking: ['创意丰富', '思想开放', '理想主义'],
      working: ['适应力强', '忠于价值观'],
      interpersonal: ['共情能力强', '善于倾听', '真诚关怀'],
      creative: ['艺术表达', '故事讲述'],
    },
    
    blindSpots: [
      { area: '实用性', description: '可能过于理想化而忽视现实', improvement: '寻找务实的合作伙伴' },
      { area: '自我批评', description: '对自己要求苛刻', improvement: '练习自我同情' },
      { area: '冲突处理', description: '回避冲突导致问题积累', improvement: '学习温和而坚定的沟通' },
    ],
    
    intimateRelationship: {
      strength: '深情且忠诚，重视精神连接',
      challenge: '可能过度理想化伴侣',
      advice: '接受伴侣的不完美，关注真实而非理想',
    },
    
    friendship: {
      strength: '温暖且支持性的朋友',
      challenge: '可能需要大量独处时间',
      advice: '坦诚沟通自己的社交节奏',
    },
    
    career: {
      bestFit: ['作家', '艺术家', '心理咨询师', '社会工作者', '教师'],
      workStyle: '追求有意义的工作，需要自主性',
      environment: '支持创意和个人表达的环境',
    },
    
    bestMatches: [
      { type: 'ENFJ', reason: 'ENFJ的外向情感帮助INFP表达自己', confidence: 'high' },
      { type: 'ENTJ', reason: 'ENTJ的结构帮助INFP实现理想', confidence: 'medium' },
      { type: 'INFJ', reason: '共享价值观深度', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '威廉·莎士比亚', title: '剧作家', description: '以深刻的人性洞察闻名', confidence: 'speculative', source: '作品主题分析' },
      { name: '约翰·列侬', title: '音乐家', description: '和平理念和音乐才华', confidence: 'likely', source: '歌词和公开言论' },
      { name: 'J.R.R.托尔金', title: '作家', description: '《魔戒》作者，创造奇幻世界', confidence: 'likely', source: '创作风格和主题' },
    ],
  },

  ENFJ: {
    code: 'ENFJ',
    name: '主人公',
    nickname: 'The Protagonist',
    dimensions: { EI: 'E', SN: 'N', TF: 'F', JP: 'J' },
    description: '富有魅力、鼓舞人心的领导者，有能力让听众着迷。真诚关心他人，善于激发潜能。',
    
    cognitiveFunctions: [
      { name: '外向情感', code: 'Fe', description: '主导功能：理解和影响他人情感' },
      { name: '内向直觉', code: 'Ni', description: '辅助功能：洞察深层模式' },
      { name: '外向实感', code: 'Se', description: '第三功能：当下体验' },
      { name: '内向思考', code: 'Ti', description: '劣势功能：内部逻辑' },
    ],
    
    strengths: {
      thinking: ['领导力强', '可靠负责', '利他主义'],
      working: ['组织能力', '激励他人', '沟通协调'],
      interpersonal: ['自然领袖', '忠诚可信', '共情能力'],
      creative: ['愿景构建', '团队凝聚'],
    },
    
    blindSpots: [
      { area: '自我牺牲', description: '过度关注他人而忽视自己', improvement: '设定个人边界' },
      { area: '批评敏感', description: '对负面反馈反应强烈', improvement: '区分建设性批评和人身攻击' },
      { area: '控制欲', description: '可能过度干预他人', improvement: '信任他人的自主能力' },
    ],
    
    intimateRelationship: {
      strength: '投入且支持性的伴侣',
      challenge: '可能过度关注伴侣而失去自我',
      advice: '保持个人兴趣和空间',
    },
    
    friendship: {
      strength: '热心且可靠的朋友',
      challenge: '可能承担过多责任',
      advice: '学会让朋友自己解决问题',
    },
    
    career: {
      bestFit: ['教师', '人力资源', '咨询师', '公关专家', '非营利组织领导'],
      workStyle: '喜欢与人合作，追求有意义的影响',
      environment: '重视团队合作和人文关怀的组织',
    },
    
    bestMatches: [
      { type: 'INFP', reason: 'INFP的深度价值观与ENFJ的外向关怀互补', confidence: 'high' },
      { type: 'INTP', reason: 'INTP的逻辑平衡ENFJ的情感', confidence: 'medium' },
      { type: 'ISFP', reason: 'ISFP的艺术气质吸引ENFJ', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '奥普拉·温弗瑞', title: '媒体大亨', description: '以共情能力和影响力改变生活', confidence: 'likely', source: '职业生涯和公开形象' },
      { name: '巴拉克·奥巴马', title: '美国前总统', description: '以希望和变革的理念激励民众', confidence: 'likely', source: '演讲和领导风格' },
      { name: '玛雅·安吉洛', title: '作家/诗人', description: '以文字激励无数人', confidence: 'speculative', source: '作品主题分析' },
    ],
  },

  ENFP: {
    code: 'ENFP',
    name: '竞选者',
    nickname: 'The Campaigner',
    dimensions: { EI: 'E', SN: 'N', TF: 'F', JP: 'P' },
    description: '热情、有创造力、爱社交的自由精神，总能找到理由微笑。充满可能性和新想法。',
    
    cognitiveFunctions: [
      { name: '外向直觉', code: 'Ne', description: '主导功能：探索可能性' },
      { name: '内向情感', code: 'Fi', description: '辅助功能：个人价值观' },
      { name: '外向思考', code: 'Te', description: '第三功能：外部组织' },
      { name: '内向实感', code: 'Si', description: '劣势功能：细节和常规' },
    ],
    
    strengths: {
      thinking: ['好奇心强', '观察敏锐', '创新思维'],
      working: ['适应力强', '热情洋溢', '多才多艺'],
      interpersonal: ['优秀沟通', '受欢迎', '激励他人'],
      creative: ['创意发散', '跨界联想'],
    },
    
    blindSpots: [
      { area: '专注力', description: '难以长期坚持单一目标', improvement: '找到真正热爱的方向' },
      { area: '过度思考', description: '可能陷入分析瘫痪', improvement: '设定决策时限' },
      { area: '情绪波动', description: '情感起伏较大', improvement: '建立情绪调节机制' },
    ],
    
    intimateRelationship: {
      strength: '充满活力和创意的伴侣',
      challenge: '可能显得不够稳定',
      advice: '通过行动证明承诺的一致性',
    },
    
    friendship: {
      strength: '有趣且热情的朋友',
      challenge: '可能承诺过多而兑现不足',
      advice: '少承诺多兑现',
    },
    
    career: {
      bestFit: ['记者', '演员', '咨询师', '创业者', '创意总监'],
      workStyle: '喜欢多样性和自由度',
      environment: '鼓励创意和人际互动的环境',
    },
    
    bestMatches: [
      { type: 'INTJ', reason: 'INTJ的战略思维与ENFP的创造力完美互补', confidence: 'high' },
      { type: 'INFJ', reason: '共享直觉和情感深度', confidence: 'high' },
      { type: 'ENTJ', reason: 'ENTJ的执行能力帮助ENFP落地想法', confidence: 'medium' },
    ],
    
    representatives: [
      { name: '罗宾·威廉姆斯', title: '喜剧演员', description: '以即兴表演和温暖人格著称', confidence: 'likely', source: '表演风格和采访' },
      { name: '小罗伯特·唐尼', title: '演员', description: '以魅力和韧性完成人生逆转', confidence: 'speculative', source: '公众形象分析' },
      { name: '威尔·史密斯', title: '演员', description: '以活力和正能量闻名', confidence: 'speculative', source: '角色选择和公开形象' },
    ],
  },

  // ==================== 守护者类型 (SJ) ====================
  
  ISTJ: {
    code: 'ISTJ',
    name: '物流师',
    nickname: 'The Logistician',
    dimensions: { EI: 'I', SN: 'S', TF: 'T', JP: 'J' },
    description: '实际且注重事实的个人，可靠性不容怀疑。重视传统和秩序，做事有条不紊。',
    
    cognitiveFunctions: [
      { name: '内向实感', code: 'Si', description: '主导功能：经验和传统' },
      { name: '外向思考', code: 'Te', description: '辅助功能：高效组织' },
      { name: '内向情感', code: 'Fi', description: '第三功能：个人价值观' },
      { name: '外向直觉', code: 'Ne', description: '劣势功能：可能性探索' },
    ],
    
    strengths: {
      thinking: ['诚实直接', '意志坚强', '责任感强'],
      working: ['冷静务实', '组织能力', '可靠性'],
      interpersonal: ['忠诚', '守信', '负责任'],
      creative: ['流程优化', '系统改进'],
    },
    
    blindSpots: [
      { area: '灵活性', description: '抗拒变化和新技术', improvement: '逐步尝试新方法' },
      { area: '情感表达', description: '可能显得冷漠', improvement: '学习表达关心' },
      { area: '完美主义', description: '对自己和他人要求过高', improvement: '接受合理的不完美' },
    ],
    
    intimateRelationship: {
      strength: '忠诚可靠的伴侣',
      challenge: '可能显得缺乏浪漫',
      advice: '学习用伴侣喜欢的方式表达爱意',
    },
    
    friendship: {
      strength: '值得信赖的朋友',
      challenge: '社交圈较小',
      advice: '主动拓展社交',
    },
    
    career: {
      bestFit: ['会计师', '审计师', '项目经理', '军官', '行政主管'],
      workStyle: '喜欢结构和明确期望',
      environment: '稳定且有清晰规则的组织',
    },
    
    bestMatches: [
      { type: 'ESFP', reason: 'ESFP的活力平衡ISTJ的严肃', confidence: 'medium' },
      { type: 'ESTP', reason: '共同的实感和思考偏好', confidence: 'medium' },
      { type: 'ISFJ', reason: '共享价值观和责任感', confidence: 'high' },
    ],
    
    representatives: [
      { name: '乔治·华盛顿', title: '美国首任总统', description: '以正直和领导力奠定建国基础', confidence: 'likely', source: '历史记录' },
      { name: '沃伦·巴菲特', title: '投资家', description: '价值投资大师，耐心和纪律', confidence: 'likely', source: '投资哲学分析' },
      { name: '安吉拉·默克尔', title: '德国前总理', description: '以稳定和务实领导著称', confidence: 'speculative', source: '领导风格分析' },
    ],
  },

  ISFJ: {
    code: 'ISFJ',
    name: '守卫者',
    nickname: 'The Defender',
    dimensions: { EI: 'I', SN: 'S', TF: 'F', JP: 'J' },
    description: '非常专注而温暖的守护者，时刻准备着保护所爱之人。无私奉献，重视和谐与传统。',
    
    cognitiveFunctions: [
      { name: '内向实感', code: 'Si', description: '主导功能：经验和记忆' },
      { name: '外向情感', code: 'Fe', description: '辅助功能：照顾他人' },
      { name: '内向思考', code: 'Ti', description: '第三功能：内部分析' },
      { name: '外向直觉', code: 'Ne', description: '劣势功能：可能性探索' },
    ],
    
    strengths: {
      thinking: ['支持他人', '可靠耐心', '观察细致'],
      working: ['忠诚热心', '实用主义', '记忆力强'],
      interpersonal: ['温暖', '体贴', '乐于助人'],
      creative: ['细节美化', '传统传承'],
    },
    
    blindSpots: [
      { area: '自我忽视', description: '过度关注他人需求', improvement: '优先照顾自己' },
      { area: '变化抗拒', description: '不喜欢突然的改变', improvement: '逐步适应新情况' },
      { area: '难以说不', description: '过度承诺导致疲惫', improvement: '设定合理边界' },
    ],
    
    intimateRelationship: {
      strength: '忠诚且关怀备至的伴侣',
      challenge: '可能压抑自己的需求',
      advice: '学会表达自己的需要',
    },
    
    friendship: {
      strength: '温暖且可靠的朋友',
      challenge: '可能过度付出',
      advice: '平衡给予和接受',
    },
    
    career: {
      bestFit: ['护士', '教师', '行政助理', '社工', '图书管理员'],
      workStyle: '喜欢帮助他人，重视稳定',
      environment: '支持性和有结构的环境',
    },
    
    bestMatches: [
      { type: 'ESTP', reason: 'ESTP的行动力平衡ISFJ的谨慎', confidence: 'medium' },
      { type: 'ESFP', reason: 'ESFP的活力带动ISFJ', confidence: 'medium' },
      { type: 'ISTJ', reason: '共享责任感和可靠性', confidence: 'high' },
    ],
    
    representatives: [
      { name: '碧昂丝', title: '歌手', description: '以敬业精神和家庭价值观著称', confidence: 'speculative', source: '公开形象分析' },
      { name: '凯特王妃', title: '英国王室成员', description: '以优雅和慈善工作闻名', confidence: 'speculative', source: '公众行为分析' },
      { name: '文森特·梵高', title: '画家', description: '细腻的情感和对细节的关注', confidence: 'speculative', source: '信件和作品分析' },
    ],
  },

  ESTJ: {
    code: 'ESTJ',
    name: '总经理',
    nickname: 'The Executive',
    dimensions: { EI: 'E', SN: 'S', TF: 'T', JP: 'J' },
    description: '出色的管理者，在管理事情或人的方面无与伦比。重视效率和传统，执行力强。',
    
    cognitiveFunctions: [
      { name: '外向思考', code: 'Te', description: '主导功能：高效组织' },
      { name: '内向实感', code: 'Si', description: '辅助功能：经验和传统' },
      { name: '外向直觉', code: 'Ne', description: '第三功能：可能性探索' },
      { name: '内向情感', code: 'Fi', description: '劣势功能：个人价值观' },
    ],
    
    strengths: {
      thinking: ['组织能力强', '忠诚尽责', '耐心可靠'],
      working: ['诚实直接', '意志坚定', '执行力'],
      interpersonal: ['可靠', '负责任', '领导力'],
      creative: ['流程改进', '效率优化'],
    },
    
    blindSpots: [
      { area: '灵活性', description: '固执于既定方式', improvement: '开放接受新方法' },
      { area: '情感敏感', description: '可能忽视他人感受', improvement: '练习共情' },
      { area: '放松', description: '难以放下工作', improvement: '安排休闲时间' },
    ],
    
    intimateRelationship: {
      strength: '稳定且负责任的伴侣',
      challenge: '可能显得控制欲强',
      advice: '给伴侣更多自主空间',
    },
    
    friendship: {
      strength: '可靠且实用的朋友',
      challenge: '可能过于说教',
      advice: '多倾听少指导',
    },
    
    career: {
      bestFit: ['经理', '军官', '法官', '财务主管', '学校管理员'],
      workStyle: '喜欢结构和明确职责',
      environment: '有清晰层级和规则的组织',
    },
    
    bestMatches: [
      { type: 'ISFP', reason: 'ISFP的灵活性平衡ESTJ的结构', confidence: 'medium' },
      { type: 'ISTP', reason: '共同的实感和思考偏好', confidence: 'medium' },
      { type: 'ESFJ', reason: '共享责任感和社交性', confidence: 'high' },
    ],
    
    representatives: [
      { name: '亨利·福特', title: '福特汽车创始人', description: '流水线生产先驱', confidence: 'likely', source: '管理创新记录' },
      { name: '索尼娅·索托马约尔', title: '美国最高法院大法官', description: '以严谨和对法律的尊重著称', confidence: 'speculative', source: '司法风格分析' },
      { name: '弗兰克·西纳特拉', title: '歌手/演员', description: '专业精神和领导力', confidence: 'speculative', source: '职业生涯分析' },
    ],
  },

  ESFJ: {
    code: 'ESFJ',
    name: '执政官',
    nickname: 'The Consul',
    dimensions: { EI: 'E', SN: 'S', TF: 'F', JP: 'J' },
    description: '极有同情心、爱社交、受欢迎的人们，总是热心提供帮助。重视和谐与他人需求。',
    
    cognitiveFunctions: [
      { name: '外向情感', code: 'Fe', description: '主导功能：照顾他人' },
      { name: '内向实感', code: 'Si', description: '辅助功能：经验和传统' },
      { name: '外向直觉', code: 'Ne', description: '第三功能：可能性探索' },
      { name: '内向思考', code: 'Ti', description: '劣势功能：内部逻辑' },
    ],
    
    strengths: {
      thinking: ['实践能力强', '忠诚可靠', '敏感温暖'],
      working: ['善于交际', '组织能力', '受欢迎'],
      interpersonal: ['热心', '体贴', '忠诚'],
      creative: ['活动策划', '人际协调'],
    },
    
    blindSpots: [
      { area: '评价敏感', description: '过度在意他人看法', improvement: '建立内在价值感' },
      { area: '批评接受', description: '难以接受负面反馈', improvement: '区分建设性批评' },
      { area: '无私过度', description: '忽视自己需求', improvement: '设定个人边界' },
    ],
    
    intimateRelationship: {
      strength: '关怀备至且忠诚的伴侣',
      challenge: '可能过度依赖伴侣认可',
      advice: '培养独立的自我价值感',
    },

    friendship: {
      strength: '热心且受欢迎的朋友',
      challenge: '可能过度介入他人生活',
      advice: '尊重朋友的独立性',
    },

    career: {
      bestFit: ['护士', '教师', '人力资源', '活动策划', '客户服务'],
      workStyle: '喜欢与人合作，重视和谐',
      environment: '支持性和有社交互动的环境',
    },

    bestMatches: [
      { type: 'ISTP', reason: 'ISTP的独立性平衡ESFJ的依赖', confidence: 'medium' },
      { type: 'ISFP', reason: 'ISFP的艺术气质吸引ESFJ', confidence: 'medium' },
      { type: 'ESTJ', reason: '共享责任感和社交性', confidence: 'high' },
    ],

    representatives: [
      { name: '泰勒·斯威夫特', title: '歌手', description: '以真诚情感和粉丝互动著称', confidence: 'speculative', source: '公众形象分析' },
      { name: '休·杰克曼', title: '演员', description: '以亲和力和敬业精神广受喜爱', confidence: 'speculative', source: '采访和公众行为' },
      { name: '比尔·克林顿', title: '美国前总统', description: '以人际魅力和政治技巧闻名', confidence: 'likely', source: '政治生涯分析' },
    ],
  },

  // ==================== 探险家类型 (SP) ====================

  ISTP: {
    code: 'ISTP',
    name: '鉴赏家',
    nickname: 'The Virtuoso',
    dimensions: { EI: 'I', SN: 'S', TF: 'T', JP: 'P' },
    description: '大胆而实际的实验家，擅长使用各种形式的工具。冷静理性，喜欢动手解决问题。',

    cognitiveFunctions: [
      { name: '内向思考', code: 'Ti', description: '主导功能：内部逻辑分析' },
      { name: '外向实感', code: 'Se', description: '辅助功能：当下体验' },
      { name: '内向直觉', code: 'Ni', description: '第三功能：模式洞察' },
      { name: '外向情感', code: 'Fe', description: '劣势功能：群体和谐' },
    ],

    strengths: {
      thinking: ['乐观活力', '创造力强', '自发理性'],
      working: ['知道轻重缓急', '动手能力', '问题解决'],
      interpersonal: [' relaxed', '不评判', '实际帮助'],
      creative: ['工具使用', '即兴发挥'],
    },

    blindSpots: [
      { area: '承诺', description: '可能回避长期承诺', improvement: '从小承诺开始建立' },
      { area: '情感表达', description: '难以表达深层情感', improvement: '学习用语言表达感受' },
      { area: '风险', description: '可能追求刺激而忽视安全', improvement: '评估风险后再行动' },
    ],

    intimateRelationship: {
      strength: '独立且尊重伴侣空间的伴侣',
      challenge: '可能显得情感疏离',
      advice: '主动分享内心想法和感受',
    },

    friendship: {
      strength: '有趣且实用的朋友',
      challenge: '可能不够主动联系',
      advice: '定期安排共同活动',
    },

    career: {
      bestFit: ['工程师', '机械师', '飞行员', '运动员', '法医'],
      workStyle: '喜欢动手操作和解决实际问题',
      environment: '允许自主行动和实践的环境',
    },

    bestMatches: [
      { type: 'ESFJ', reason: 'ESFJ的关怀平衡ISTP的独立', confidence: 'medium' },
      { type: 'ESTJ', reason: '共同的实感和思考偏好', confidence: 'medium' },
      { type: 'ISFP', reason: '共享感知偏好，轻松相处', confidence: 'high' },
    ],

    representatives: [
      { name: '克林特·伊斯特伍德', title: '演员/导演', description: '硬汉形象代表，冷静风格', confidence: 'likely', source: '角色和公开形象' },
      { name: '贝尔·格里尔斯', title: '探险家', description: '荒野求生专家，实用技能', confidence: 'likely', source: '节目表现分析' },
      { name: '迈克尔·乔丹', title: '篮球运动员', description: '以冷静和竞争精神著称', confidence: 'speculative', source: '比赛风格分析' },
    ],
  },

  ISFP: {
    code: 'ISFP',
    name: '探险家',
    nickname: 'The Adventurer',
    dimensions: { EI: 'I', SN: 'S', TF: 'F', JP: 'P' },
    description: '灵活有魅力的艺术家，时刻准备着探索和体验新鲜事物。活在当下，享受感官体验。',

    cognitiveFunctions: [
      { name: '内向情感', code: 'Fi', description: '主导功能：个人价值观' },
      { name: '外向实感', code: 'Se', description: '辅助功能：当下体验' },
      { name: '内向直觉', code: 'Ni', description: '第三功能：模式洞察' },
      { name: '外向思考', code: 'Te', description: '劣势功能：外部组织' },
    ],

    strengths: {
      thinking: ['魅力十足', '想象力丰富', '艺术气质'],
      working: ['热情好奇', '灵活开放', '审美出众'],
      interpersonal: ['温和', '体贴', '不评判'],
      creative: ['艺术表达', '美感创造'],
    },

    blindSpots: [
      { area: '规划', description: '缺乏长期规划能力', improvement: '设定小目标逐步实现' },
      { area: '冲突', description: '极度回避冲突', improvement: '学习温和表达分歧' },
      { area: '批评', description: '对批评非常敏感', improvement: '区分建设性反馈' },
    ],

    intimateRelationship: {
      strength: '温柔且充满爱意的伴侣',
      challenge: '可能回避深度对话',
      advice: '练习表达内心真实感受',
    },

    friendship: {
      strength: '温暖且有趣的朋友',
      challenge: '可能难以深入交流',
      advice: '尝试分享更多个人想法',
    },

    career: {
      bestFit: ['艺术家', '设计师', '音乐家', '厨师', '兽医'],
      workStyle: '喜欢自由创作，讨厌严格规则',
      environment: '支持创意和个人表达的环境',
    },

    bestMatches: [
      { type: 'ESTJ', reason: 'ESTJ的结构帮助ISFP实现想法', confidence: 'medium' },
      { type: 'ESFJ', reason: 'ESFJ的关怀温暖ISFP', confidence: 'medium' },
      { type: 'ENFJ', reason: 'ENFJ的深度激发ISFP表达', confidence: 'high' },
    ],

    representatives: [
      { name: '迈克尔·杰克逊', title: '流行音乐之王', description: '以独特艺术风格影响全球', confidence: 'likely', source: '艺术成就和风格' },
      { name: '鲍勃·迪伦', title: '音乐家/诗人', description: '诺贝尔文学奖得主，自由精神', confidence: 'likely', source: '歌词和生活方式' },
      { name: '弗里达·卡罗', title: '画家', description: '以自画像和情感表达闻名', confidence: 'likely', source: '艺术作品分析' },
    ],
  },

  ESTP: {
    code: 'ESTP',
    name: '企业家',
    nickname: 'The Entrepreneur',
    dimensions: { EI: 'E', SN: 'S', TF: 'T', JP: 'P' },
    description: '聪明、精力充沛、善于感知的人，真心享受生活在边缘。行动派，善于把握机会。',

    cognitiveFunctions: [
      { name: '外向实感', code: 'Se', description: '主导功能：当下体验' },
      { name: '内向思考', code: 'Ti', description: '辅助功能：逻辑分析' },
      { name: '外向情感', code: 'Fe', description: '第三功能：社交魅力' },
      { name: '内向直觉', code: 'Ni', description: '劣势功能：长远规划' },
    ],

    strengths: {
      thinking: ['大胆直接', '理性实用', '观察敏锐'],
      working: ['社交能力强', '感知力强', '行动力'],
      interpersonal: ['魅力', '幽默', '实际帮助'],
      creative: ['即兴发挥', '机会把握'],
    },

    blindSpots: [
      { area: '耐心', description: '缺乏长期坚持的耐心', improvement: '找到真正热爱的领域' },
      { area: '风险', description: '可能冲动行事', improvement: '三思而后行' },
      { area: '承诺', description: '回避长期承诺', improvement: '从小事建立信任' },
    ],

    intimateRelationship: {
      strength: '充满活力和趣味的伴侣',
      challenge: '可能显得不够稳定',
      advice: '通过一致的行动证明可靠性',
    },

    friendship: {
      strength: '有趣且冒险的朋友',
      challenge: '可能过于以自我为中心',
      advice: '多关注朋友的需求',
    },

    career: {
      bestFit: ['销售员', '企业家', '运动员', '警察', '急救人员'],
      workStyle: '喜欢行动和即时反馈',
      environment: '快节奏且允许自主决策的环境',
    },

    bestMatches: [
      { type: 'ISFJ', reason: 'ISFJ的稳定性平衡ESTP的变化', confidence: 'medium' },
      { type: 'ISTJ', reason: '共同的实感和思考偏好', confidence: 'medium' },
      { type: 'ESFJ', reason: 'ESFJ的关怀温暖ESTP', confidence: 'medium' },
    ],

    representatives: [
      { name: '麦当娜', title: '流行天后', description: '以大胆创新和商业头脑著称', confidence: 'speculative', source: '职业生涯分析' },
      { name: '杰克·尼科尔森', title: '演员', description: '以即兴表演能力闻名', confidence: 'speculative', source: '表演风格分析' },
      { name: '厄内斯特·海明威', title: '作家', description: '以冒险精神和简洁文风著称', confidence: 'likely', source: '生活和写作风格' },
    ],
  },

  ESFP: {
    code: 'ESFP',
    name: '表演者',
    nickname: 'The Entertainer',
    dimensions: { EI: 'E', SN: 'S', TF: 'F', JP: 'P' },
    description: '自发的、精力充沛的表演者，生活在他们周围永远不会无聊。热爱生活，善于带动气氛。',

    cognitiveFunctions: [
      { name: '外向实感', code: 'Se', description: '主导功能：当下体验' },
      { name: '内向情感', code: 'Fi', description: '辅助功能：个人价值观' },
      { name: '外向思考', code: 'Te', description: '第三功能：外部组织' },
      { name: '内向直觉', code: 'Ni', description: '劣势功能：长远规划' },
    ],

    strengths: {
      thinking: ['大胆原创', '展示能力强', '审美出众'],
      working: ['实践技能', '观察敏锐', '适应力'],
      interpersonal: ['热情', '友好', '感染力'],
      creative: ['表演天赋', '氛围营造'],
    },

    blindSpots: [
      { area: '规划', description: '缺乏长期规划', improvement: '设定简单目标' },
      { area: '深度', description: '可能回避深度话题', improvement: '练习倾听和反思' },
      { area: '承诺', description: '可能难以坚持', improvement: '找到真正热爱的方向' },
    ],

    intimateRelationship: {
      strength: '有趣且充满活力的伴侣',
      challenge: '可能回避严肃对话',
      advice: '学习进行深度情感交流',
    },

    friendship: {
      strength: '派对灵魂，带来欢乐',
      challenge: '可能表面化',
      advice: '发展更深层次的友谊',
    },

    career: {
      bestFit: ['演员', '销售', '旅游向导', '活动策划', '健身教练'],
      workStyle: '喜欢与人互动，讨厌单调',
      environment: '充满活力和社交机会的环境',
    },

    bestMatches: [
      { type: 'ISTJ', reason: 'ISTJ的稳定性平衡ESFP的变化', confidence: 'medium' },
      { type: 'ISFJ', reason: 'ISFJ的关怀温暖ESFP', confidence: 'medium' },
      { type: 'INFJ', reason: 'INFJ的深度激发ESFP成长', confidence: 'medium' },
    ],

    representatives: [
      { name: '玛丽莲·梦露', title: '演员', description: '好莱坞黄金时代偶像', confidence: 'likely', source: '公众形象和表演' },
      { name: '阿黛尔', title: '歌手', description: '以真挚情感打动观众', confidence: 'speculative', source: '表演风格分析' },
      { name: '杰米·福克斯', title: '演员/音乐家', description: '多才多艺的表演者', confidence: 'speculative', source: '职业生涯分析' },
    ],
  },
};

// 获取所有类型代码列表
export const getAllTypeCodes = (): string[] => {
  return Object.keys(MBTI_TYPES);
};

// 根据代码获取类型信息
export const getTypeByCode = (code: string): MBTIType | undefined => {
  return MBTI_TYPES[code.toUpperCase()];
};

// 获取类型的维度值
export const getDimensionValue = (typeCode: string, dimension: 'EI' | 'SN' | 'TF' | 'JP'): string => {
  const type = MBTI_TYPES[typeCode.toUpperCase()];
  if (!type) return '';
  return type.dimensions[dimension];
};

// 16种人格类型的emoji图标映射（统一风格、符合特质）
export const TYPE_EMOJIS: Record<string, string> = {
  // 分析家 (NT) - 紫色系
  INTJ: '🏗️', // 建筑师 - 建筑/结构
  INTP: '🔍', // 逻辑学家 - 探索/分析
  ENTJ: '👑', // 指挥官 - 领导/权威
  ENTP: '⚡', // 辩论家 - 灵感/能量

  // 外交家 (NF) - 绿色系
  INFJ: '🌟', // 提倡者 - 理想/指引
  INFP: '🦋', // 调停者 - 蜕变/自由
  ENFJ: '🤝', // 主人公 - 连接/协作
  ENFP: '🎨', // 竞选者 - 创意/多彩

  // 守护者 (SJ) - 蓝色系
  ISTJ: '📋', // 物流师 - 秩序/清单
  ISFJ: '🛡️', // 守卫者 - 保护/守护
  ESTJ: '⚖️', // 总经理 - 公正/平衡
  ESFJ: '💝', // 执政官 - 关怀/爱心

  // 探险家 (SP) - 橙色系
  ISTP: '🔧', // 鉴赏家 - 工具/实操
  ISFP: '🎵', // 艺术家 - 艺术/感知
  ESTP: '🎯', // 企业家 - 目标/行动
  ESFP: '🎭', // 表演者 - 舞台/表现
};

// 获取类型的emoji图标
export const getTypeEmoji = (code: string): string => {
  return TYPE_EMOJIS[code.toUpperCase()] || '❓';
};
