export default defineAppConfig({
  pages: [
    'pages/index/index',
    'pages/explore/index',
    'pages/match/index',
    'pages/compare/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#667eea',
    navigationBarTitleText: '人类观察计划',
    navigationBarTextStyle: 'white'
  },
  tabBar: {
    color: '#94a3b8',
    selectedColor: '#667eea',
    backgroundColor: '#ffffff',
    list: [
      {
        pagePath: 'pages/explore/index',
        text: '探索',
        iconPath: './assets/tabbar/search.png',
        selectedIconPath: './assets/tabbar/search-active.png'
      },
      {
        pagePath: 'pages/match/index',
        text: '匹配',
        iconPath: './assets/tabbar/heart.png',
        selectedIconPath: './assets/tabbar/heart-active.png'
      },
      {
        pagePath: 'pages/compare/index',
        text: '比较',
        iconPath: './assets/tabbar/scale.png',
        selectedIconPath: './assets/tabbar/scale-active.png'
      }
    ]
  }
})
