import{g as q,E as Y,a as K,s as Z,r as h,_ as D,t as g,j as u,V as v,T as J,b as A,c as H,d as O,e as P,f as Q,h as X,i as ee,k as ae,l as te,m as ne,R as I,n as x,o as l,p as y}from"./vendors.eb2a8c75.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))t(n);new MutationObserver(n=>{for(const r of n)if(r.type==="childList")for(const o of r.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&t(o)}).observe(document,{childList:!0,subtree:!0});function a(n){const r={};return n.integrity&&(r.integrity=n.integrity),n.referrerPolicy&&(r.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?r.credentials="include":n.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function t(n){if(n.ep)return;n.ep=!0;const r=a(n);fetch(n.href,r)}})();var re=`
/* H5 端隐藏 TabBar 空图标（只隐藏没有 src 的图标） */
.weui-tabbar__icon:not([src]),
.weui-tabbar__icon[src=''] {
  display: none !important;
}

.weui-tabbar__item:has(.weui-tabbar__icon:not([src])) .weui-tabbar__label,
.weui-tabbar__item:has(.weui-tabbar__icon[src='']) .weui-tabbar__label {
  margin-top: 0 !important;
}

/* Vite 错误覆盖层无法选择文本的问题 */
vite-error-overlay {
  /* stylelint-disable-next-line property-no-vendor-prefix */
  -webkit-user-select: text !important;
}

vite-error-overlay::part(window) {
  max-width: 90vw;
  padding: 10px;
}

.taro_page {
  overflow: auto;
}

::-webkit-scrollbar {
  width: 4px;
  height: 4px;
}

::-webkit-scrollbar-track {
  background: transparent;
}

::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 2px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.3);
}

/* H5 顶部 navbar / 底部 tabbar 高度变量（无对应栏时为 0） */
body { --navbar-h: 0px; --tabbar-h: 0px; }
body.h5-navbar-visible { --navbar-h: 44px; }
body:not(.no-tabbar) { --tabbar-h: calc(50px + env(safe-area-inset-bottom)); }

/* 模拟真机效果 */
.taro_page {
  box-sizing: border-box;
  border-top: var(--navbar-h) solid transparent;
  border-bottom: var(--tabbar-h) solid transparent;
  transform: translateZ(0);
}

/* min-h-screen / h-screen 这类用 100vh 的内层容器：把锚点从视口换成"可见内容区"，避免被 navbar / tabbar 盖住 */
.taro_page .min-h-screen {
  min-height: calc(100vh - var(--navbar-h) - var(--tabbar-h));
}
.taro_page .h-screen {
  height: calc(100vh - var(--navbar-h) - var(--tabbar-h));
}

/*
 * H5 端 rem 适配：与小程序 rpx 缩放一致
 * 375px 屏幕：1rem = 16px，小程序 32rpx = 16px
 */
html {
    font-size: 4vw !important;
}

/* H5 端组件默认样式修复 */
taro-view-core {
    display: block;
}

taro-text-core {
    display: inline;
}

taro-input-core {
    display: block;
    width: 100%;
}

taro-input-core.taro-otp-hidden-input input {
    color: transparent;
    caret-color: transparent;
    -webkit-text-fill-color: transparent;
}

/* Textarea 关闭浏览器自带 resize 把手（移动端无意义） */
taro-textarea-core > textarea,
.taro-textarea,
textarea.taro-textarea {
    resize: none !important;
}
`;function oe(){var i=document.createElement("style");i.innerHTML=re,document.head.appendChild(i)}function ie(){var i=function(){var t=!!document.querySelector(".taro-tabbar__container");document.body.classList.toggle("no-tabbar",!t)};i();var e=new MutationObserver(i);e.observe(document.body,{childList:!0,subtree:!0})}function ue(){oe(),ie()}function se(){var i=q();if(i===Y.WEAPP)try{var e=K(),a=e.miniProgram.envVersion;console.log("[Debug] envVersion:",a),a!=="release"&&Z({enableDebug:!0})}catch(t){console.error("[Debug] 开启调试模式失败:",t)}}var ce={title:"",bgColor:"#ffffff",textStyle:"black",navStyle:"default",transparent:"none",leftIcon:"none"},le=function(){var e,a=A();return(a==null||(e=a.config)===null||e===void 0?void 0:e.window)||{}},de=function(){var e,a,t=(e=A())===null||e===void 0||(e=e.config)===null||e===void 0?void 0:e.tabBar;return new Set((t==null||(a=t.list)===null||a===void 0?void 0:a.map(function(n){return n.pagePath}))||[])},j=function(){var e,a=A();return(a==null||(e=a.config)===null||e===void 0||(e=e.pages)===null||e===void 0?void 0:e[0])||"pages/index/index"},E=function(e){return e.replace(/^\//,"")},ve=function(e,a,t,n){if(!e)return"none";var r=E(e),o=E(n),B=r===o,T=a.has(r)||a.has("/".concat(r)),d=t>1;return T||B?"none":d?"back":"home"},ge=function(){var e=h.useState(ce),a=D(e,2),t=a[0],n=a[1],r=h.useState(0),o=D(r,2),B=o[0],T=o[1],d=h.useCallback(function(){var s=g.getCurrentPages();if(s.length!==0){var c=s[s.length-1],k=(c==null?void 0:c.route)||"";if(k){var p=(c==null?void 0:c.config)||{},b=le(),W=de(),G=j(),U=E(k),$=E(G);n({title:document.title||p.navigationBarTitleText||b.navigationBarTitleText||"",bgColor:p.navigationBarBackgroundColor||b.navigationBarBackgroundColor||"#ffffff",textStyle:p.navigationBarTextStyle||b.navigationBarTextStyle||"black",navStyle:p.navigationStyle||b.navigationStyle||"default",transparent:p.transparentTitle||b.transparentTitle||"none",leftIcon:ve(U,W,s.length,$)})}}},[]);g.useDidShow(function(){d()}),g.usePageScroll(function(s){var c=s.scrollTop;t.transparent==="auto"&&T(Math.min(c/100,1))}),h.useEffect(function(){var s=null,c=new MutationObserver(function(){s&&clearTimeout(s),s=setTimeout(function(){d()},50)});return c.observe(document.head,{subtree:!0,childList:!0,characterData:!0}),d(),function(){c.disconnect(),s&&clearTimeout(s)}},[d]);var C=t.navStyle!=="custom";if(h.useEffect(function(){C?document.body.classList.add("h5-navbar-visible"):document.body.classList.remove("h5-navbar-visible")},[C]),!C)return u.jsx(u.Fragment,{});var S=t.textStyle==="white"?"#fff":"#333",R=t.textStyle==="white"?"text-white":"text-gray-800",V=function(){return t.transparent==="always"?{backgroundColor:"transparent"}:t.transparent==="auto"?{backgroundColor:t.bgColor,opacity:B}:{backgroundColor:t.bgColor}},M=function(){return g.navigateBack()},z=function(){var c=j();g.reLaunch({url:"/".concat(c)})};return u.jsxs(u.Fragment,{children:[u.jsxs(v,{className:"fixed top-0 left-0 right-0 h-11 flex items-center justify-center z-1000",style:V(),children:[t.leftIcon==="back"&&u.jsx(v,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:M,children:u.jsx(v,{className:"i-lucide-chevron-left w-6 h-6",style:{color:S}})}),t.leftIcon==="home"&&u.jsx(v,{className:"absolute left-2 top-1/2 -translate-y-1/2 p-1 flex items-center justify-center",onClick:z,children:u.jsx(v,{className:"i-lucide-house w-6 h-6",style:{color:S}})}),u.jsx(J,{className:"text-base font-medium max-w-3/5 truncate ".concat(R),children:t.title})]}),u.jsx(v,{className:"h-11 shrink-0"})]})},pe=function(e){var a=e.children;return u.jsxs(u.Fragment,{children:[u.jsx(ge,{}),a]})},be=function(e){var a=e.children;return g.useLaunch(function(){se(),ue()}),u.jsx(pe,{children:a})},he=function(e){var a=e.children;return u.jsx(be,{children:a})},m=H.__taroAppConfig={router:{mode:"hash"},pages:["pages/index/index","pages/explore/index","pages/match/index","pages/compare/index"],window:{backgroundTextStyle:"light",navigationBarBackgroundColor:"#667eea",navigationBarTitleText:"人类观察计划",navigationBarTextStyle:"white"},tabBar:{color:"#94a3b8",selectedColor:"#667eea",backgroundColor:"#ffffff",list:[{pagePath:"pages/explore/index",text:"探索",iconPath:"./assets/tabbar/search.png",selectedIconPath:"./assets/tabbar/search-active.png"},{pagePath:"pages/match/index",text:"匹配",iconPath:"./assets/tabbar/heart.png",selectedIconPath:"./assets/tabbar/heart-active.png"},{pagePath:"pages/compare/index",text:"比较",iconPath:"./assets/tabbar/scale.png",selectedIconPath:"./assets/tabbar/scale-active.png"}]}},w=[],F=[];w[0]="/static/images/search.png";F[0]="/static/images/search-active.png";w[1]="/static/images/heart.png";F[1]="/static/images/heart-active.png";w[2]="/static/images/scale.png";F[2]="/static/images/scale-active.png";var L=m.tabBar.list;for(var f=0;f<L.length;f++){var _=L[f];_.iconPath&&(_.iconPath=w[f]),_.selectedIconPath&&(_.selectedIconPath=F[f])}m.routes=[Object.assign({path:"pages/index/index",load:function(){var i=x(l().m(function a(t,n){var r;return l().w(function(o){for(;;)switch(o.n){case 0:return o.n=1,y(()=>import("./index.9d301cd9.js"),["./index.9d301cd9.js","./vendors.eb2a8c75.js","../css/vendors.8886af03.css"],import.meta.url);case 1:return r=o.v,o.a(2,[r,t,n])}},a)}));function e(a,t){return i.apply(this,arguments)}return e}()},{navigationBarTitleText:"人类观察计划",navigationBarBackgroundColor:"#667eea",navigationBarTextStyle:"white"}),Object.assign({path:"pages/explore/index",load:function(){var i=x(l().m(function a(t,n){var r;return l().w(function(o){for(;;)switch(o.n){case 0:return o.n=1,y(()=>import("./index.e6a2f031.js"),["./index.e6a2f031.js","./vendors.eb2a8c75.js","../css/vendors.8886af03.css","./common.76d4b730.js"],import.meta.url);case 1:return r=o.v,o.a(2,[r,t,n])}},a)}));function e(a,t){return i.apply(this,arguments)}return e}()},{navigationBarTitleText:"探索",navigationBarBackgroundColor:"#667eea",navigationBarTextStyle:"white"}),Object.assign({path:"pages/match/index",load:function(){var i=x(l().m(function a(t,n){var r;return l().w(function(o){for(;;)switch(o.n){case 0:return o.n=1,y(()=>import("./index.d83ab02d.js"),["./index.d83ab02d.js","./vendors.eb2a8c75.js","../css/vendors.8886af03.css","./common.76d4b730.js"],import.meta.url);case 1:return r=o.v,o.a(2,[r,t,n])}},a)}));function e(a,t){return i.apply(this,arguments)}return e}()},{navigationBarTitleText:"匹配",navigationBarBackgroundColor:"#667eea",navigationBarTextStyle:"white"}),Object.assign({path:"pages/compare/index",load:function(){var i=x(l().m(function a(t,n){var r;return l().w(function(o){for(;;)switch(o.n){case 0:return o.n=1,y(()=>import("./index.fdf53747.js"),["./index.fdf53747.js","./vendors.eb2a8c75.js","../css/vendors.8886af03.css","./common.76d4b730.js"],import.meta.url);case 1:return r=o.v,o.a(2,[r,t,n])}},a)}));function e(a,t){return i.apply(this,arguments)}return e}()},{navigationBarTitleText:"比较",navigationBarBackgroundColor:"#667eea",navigationBarTextStyle:"white"})];Object.assign(O,{findDOMNode:P.findDOMNode,render:P.render,unstable_batchedUpdates:P.unstable_batchedUpdates});Q();var fe=X(he,I,O,m),N=ee({window:H});ae(m,N);te(N,fe,m,I);ne({designWidth:750,deviceRatio:{375:2,640:1.17,750:1,828:.905},baseFontSize:20,unitPrecision:void 0,targetUnit:void 0});
