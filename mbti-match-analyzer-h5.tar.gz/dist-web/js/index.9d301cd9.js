import{t as e}from"./vendors.eb2a8c75.js";function n(){return e.useLoad(function(){console.log("首页加载完成"),e.switchTab({url:"/pages/explore/index"})}),null}export{n as default};
